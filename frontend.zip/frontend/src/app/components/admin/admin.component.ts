import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-admin',
  standalone: true,
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
  imports: [CommonModule]
})
export class AdminComponent implements OnInit {
  doctorCount: number = 0;
  patientCount: number = 0;
  users: any[] = [];
  loading = false;
  errorMsg = '';

  constructor(private userService: UserService) {}

  ngOnInit() {
    this.fetchUsers();
  }

  fetchUsers() {
    this.loading = true;
    this.userService.getAllUsers().subscribe({
      next: (res: any) => {
        this.users = res;
        this.doctorCount = this.users.filter(u => u.role === 'DOCTOR').length;
        this.patientCount = this.users.filter(u => u.role === 'PATIENT').length;
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load users.';
        this.loading = false;
      }
    });
  }

  editUser(user: any) {
    // Implement edit logic (open modal, etc.)
    alert('Edit user: ' + user.name);
  }

  deleteUser(user: any) {
    if (confirm('Are you sure you want to delete this user?')) {
      this.userService.deleteUser(user.id).subscribe({
        next: () => this.fetchUsers(),
        error: () => alert('Failed to delete user.')
      });
    }
  }
}
