
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IssuesService } from '../../services/issues.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-issues',
  standalone: true,
  templateUrl: './my-issues.component.html',
  styleUrls: ['./my-issues.component.css'],
  imports: [CommonModule]
})
export class MyIssuesComponent implements OnInit {
  issues: any[] = [];
  open: any[] = [];
  closed: any[] = [];
  loading = false;
  errorMsg = '';
  showToast = false;
  toastMsg = '';

  constructor(private issuesService: IssuesService, private router: Router) {}

  ngOnInit() {
    this.fetchIssues();
  }

  getCitizenId() {
    const token = localStorage.getItem('jwtToken');
    if (!token) return null;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.userId || payload.id || null;
    } catch {
      return null;
    }
  }

  fetchIssues() {
    this.loading = true;
    const citizenId = this.getCitizenId();
    if (!citizenId) {
      this.errorMsg = 'Citizen not authenticated.';
      this.loading = false;
      return;
    }
    this.issuesService.getIssuesByCitizen(citizenId).subscribe({
      next: (res) => {
        this.issues = res || [];
        this.splitIssues();
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load issues.';
        this.loading = false;
      }
    });
  }

  splitIssues() {
    // Open: status PENDING or IN_PROGRESS
    this.open = this.issues.filter(i => i.status === 'PENDING' || i.status === 'IN_PROGRESS');
    // Closed: status RESOLVED or REJECTED
    this.closed = this.issues.filter(i => i.status === 'RESOLVED' || i.status === 'REJECTED');
  }

  confirmCancel(issue: any) {
    if (window.confirm('Are you sure you want to cancel this issue?')) {
      this.cancelIssue(issue.id);
    }
  }

  cancelIssue(issueId: number) {
    this.loading = true;
    this.issuesService.cancelIssue(issueId).subscribe({
      next: () => {
        this.showToastMsg('Issue cancelled successfully!');
        this.fetchIssues();
      },
      error: () => {
        this.showToastMsg('Failed to cancel issue.');
        this.loading = false;
      }
    });
  }

  showToastMsg(msg: string) {
    this.toastMsg = msg;
    this.showToast = true;
    setTimeout(() => {
      this.showToast = false;
    }, 2000);
  }
}
