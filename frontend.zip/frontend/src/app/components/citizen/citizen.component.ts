
import { Component, OnInit } from '@angular/core';
import { IssuesService } from '../../services/issues.service';
import { UserService } from '../../services/user.service';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from '../shared/navbar/navbar.component';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { ReportIssueComponent } from './report-issue.component';
import { MyIssuesComponent } from './my-issues.component';
import { EditProfileComponent } from './edit-profile.component';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-citizen',
  standalone: true,
  templateUrl: './citizen.component.html',
  styleUrls: ['./citizen.component.css'],
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent, RouterOutlet]
})
export class CitizenComponent implements OnInit {
  activeTab: string = 'report';
  issues: any[] = [];
  employees: any[] = [];
  loading = false;
  errorMsg = '';
  showReportForm = false;
  reportForm: FormGroup;
  reportMsg = '';

  constructor(
    private issuesService: IssuesService,
    private userService: UserService,
    private fb: FormBuilder
  ) {
    this.reportForm = this.fb.group({
      employeeId: ['', Validators.required],
      date: ['', Validators.required],
      time: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  logout() {
    localStorage.removeItem('jwtToken');
    localStorage.removeItem('userRole');
    window.location.href = '/login';
  }

  ngOnInit() {
    this.fetchIssues();
    this.fetchEmployees();
  }

  fetchIssues() {
    this.loading = true;
    this.issuesService.getAllIssues().subscribe({
      next: (res: any) => {
        this.issues = res;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  fetchEmployees() {
    this.userService.getAllUsers().subscribe({
      next: (res: any) => {
        this.employees = (res || []).filter((u: any) => u.role === 'EMPLOYEE');
      },
      error: () => {
        this.employees = [];
      }
    });
  }

  openReportForm() {
    this.showReportForm = true;
    this.reportMsg = '';
    this.reportForm.reset();
  }

  closeReportForm() {
    this.showReportForm = false;
  }

  reportIssue() {
    if (this.reportForm.invalid) return;
    this.issuesService.reportIssue(this.reportForm.value).subscribe({
      next: () => {
        this.reportMsg = 'Issue reported!';
        this.fetchIssues();
        setTimeout(() => this.closeReportForm(), 1200);
      },
      error: () => {
        this.reportMsg = 'Failed to report issue.';
      }
    });
  }

  cancelIssue(issue: any) {
    this.issuesService.cancelIssue(issue.id).subscribe({
      next: () => this.fetchIssues(),
      error: () => alert('Failed to cancel issue.')
    });
  }
}
