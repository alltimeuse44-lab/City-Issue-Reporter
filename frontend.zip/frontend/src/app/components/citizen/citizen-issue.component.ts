
import { Component, OnInit } from '@angular/core';
import { IssuesService } from '../../services/issues.service';
import { UserService } from '../../services/user.service';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { NavbarComponent } from '../shared/navbar/navbar.component';

@Component({
  selector: 'app-citizen-issue',
  standalone: true,
  templateUrl: './citizen-issue.component.html',
  styleUrls: ['./citizen-issue.component.css'],
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent]
})
export class CitizenIssueComponent implements OnInit {
  employees: any[] = [];
  reportForm: FormGroup;
  successMsg = '';
  errorMsg = '';
  loading = false;

  constructor(
    private userService: UserService,
    private issuesService: IssuesService,
    private fb: FormBuilder,
    private router: Router
  ) {
    this.reportForm = this.fb.group({
      title: ['', Validators.required],
      location: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.loadEmployees();
  }

  loadEmployees() {
    this.loading = true;
    this.userService.getAllUsers().subscribe({
      next: (res: any) => {
        this.employees = res.filter((u: any) => u.role === 'EMPLOYEE');
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load employees.';
        this.loading = false;
      }
    });
  }

  reportIssue() {
    if (this.reportForm.invalid) return;
    const token = localStorage.getItem('jwtToken');
    let userId = null;
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        userId = payload.userId || payload.id || null;
      } catch {}
    }
    const payload = {
      ...this.reportForm.value,
      status: 'PENDING',
      userId
    };
    this.issuesService.reportIssue(payload).subscribe({
      next: () => {
        this.successMsg = 'Issue reported successfully!';
        setTimeout(() => this.router.navigate(['/citizen/issues']), 1500);
      },
      error: () => {
        this.errorMsg = 'Failed to report issue.';
      }
    });
  }
}
