
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule, DatePipe } from '@angular/common';

@Component({
  selector: 'app-citizen-dashboard',
  standalone: true,
  templateUrl: './citizen-dashboard.component.html',
  styleUrls: ['./citizen-dashboard.component.css'],
  imports: [CommonModule]
})
export class CitizenDashboardComponent implements OnInit {
  reportedIssues: any[] = [];
  stats = { total: 0, open: 0, resolved: 0, rejected: 0 };
  loadingIssues = false;
  loadingStats = false;
  errorMsg = '';
  citizenName: string = '';
  latestIssue: any = {};
  notifications: any[] = [];

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    this.setCitizenName();
    this.fetchStats();
    this.fetchReportedIssues();
    this.fetchLatestIssue();
    this.fetchNotifications();
  }

  setCitizenName() {
    const token = localStorage.getItem('jwtToken');
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        this.citizenName = payload.sub || payload.username || 'Citizen';
      } catch {
        this.citizenName = 'Citizen';
      }
    }
  }

  getCitizenId() {
    const token = localStorage.getItem('jwtToken');
    if (!token) return null;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.userId || payload.id || null;
    } catch {
      return null;
    }
  }

  fetchStats() {
    this.loadingStats = true;
    const citizenId = this.getCitizenId();
    if (!citizenId) return;
    this.http.get<any>(`/api/issues/citizen/${citizenId}/stats`).subscribe({
      next: (res) => {
        this.stats = {
          total: res.total || 0,
          open: res.open || 0,
          resolved: res.resolved || 0,
          rejected: res.rejected || 0
        };
        this.loadingStats = false;
      },
      error: () => {
        this.loadingStats = false;
      }
    });
  }

  fetchReportedIssues() {
    this.loadingIssues = true;
    const citizenId = this.getCitizenId();
    if (!citizenId) return;
    this.http.get<any[]>(`/api/issues/citizen/${citizenId}/reported`).subscribe({
      next: (res) => {
        this.reportedIssues = res || [];
        this.loadingIssues = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load reported issues.';
        this.loadingIssues = false;
      }
    });
  }

  fetchLatestIssue() {
    const citizenId = this.getCitizenId();
    if (!citizenId) return;
    this.http.get<any>(`/api/issues/citizen/${citizenId}/latest`).subscribe({
      next: (res) => {
        this.latestIssue = res || {};
      },
      error: () => {
        this.latestIssue = {};
      }
    });
  }

  fetchNotifications() {
    const citizenId = this.getCitizenId();
    if (!citizenId) return;
    this.http.get<any[]>(`/api/issues/citizen/${citizenId}/notifications`).subscribe({
      next: (res) => {
        this.notifications = res || [];
      },
      error: () => {
        this.notifications = [];
      }
    });
  }

  goToReportIssue() {
    this.router.navigate(['/citizen/report']);
  }

  goToViewIssues() {
    this.router.navigate(['/citizen/issues']);
  }
}
