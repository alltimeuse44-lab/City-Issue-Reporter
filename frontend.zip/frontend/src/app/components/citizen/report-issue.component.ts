
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IssuesService } from '../../services/issues.service';
import { UserService } from '../../services/user.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-report-issue',
  standalone: true,
  templateUrl: './report-issue.component.html',
  styleUrls: ['./report-issue.component.css'],
  imports: [CommonModule, ReactiveFormsModule]
})
export class ReportIssueComponent implements OnInit {
  reportForm: FormGroup;
  employees: any[] = [];
  loadingEmployees = false;
  successMsg = '';
  errorMsg = '';

  constructor(
    private fb: FormBuilder,
    private issuesService: IssuesService,
    private userService: UserService,
    private router: Router
  ) {
    this.reportForm = this.fb.group({
      title: ['', Validators.required],
      location: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.fetchEmployees();
  }

  fetchEmployees() {
    this.loadingEmployees = true;
    this.userService.getAllUsers().subscribe({
      next: (res) => {
        this.employees = (res || []).filter((u: any) => u.role === 'EMPLOYEE');
        this.loadingEmployees = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load employees.';
        this.loadingEmployees = false;
      }
    });
  }

  getCitizenId() {
    const token = localStorage.getItem('jwtToken');
    if (!token) return null;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.userId || payload.id || null;
    } catch {
      return null;
    }
  }

  reportIssue() {
    if (this.reportForm.invalid) return;

    const token = localStorage.getItem('jwtToken');
    let userId = null;
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        userId = payload.userId || payload.id || null;
      } catch {}
    }
    if (!userId) {
      this.errorMsg = 'Citizen not authenticated.';
      return;
    }

    const payload = {
      ...this.reportForm.value,
      status: 'PENDING',
      userId
    };

    this.issuesService.reportIssue(payload).subscribe({
      next: () => {
        this.successMsg = 'Issue reported successfully!';
        setTimeout(() => this.router.navigate(['/citizen/issues']), 1500);
      },
      error: () => {
        this.errorMsg = 'Failed to report issue.';
      }
    });
  }
}
