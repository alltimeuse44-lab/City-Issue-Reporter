import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: true,
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  imports: [RouterModule]
})

export class NavbarComponent {
  citizenName: string = '';

  constructor(private router: Router) {
    this.setCitizenName();
  }

  setCitizenName() {
    const token = localStorage.getItem('jwtToken');
    if (!token) return;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      this.citizenName = payload.sub || payload.username || 'Citizen';
    } catch {
      this.citizenName = 'Citizen';
    }
  }

  logout() {
    localStorage.removeItem('jwtToken');
    localStorage.removeItem('userRole');
    this.router.navigate(['/login']);
  }
}
