import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-employee-profile',
  standalone: true,
  templateUrl: './employee-profile.component.html',
  styleUrls: ['./employee-profile.component.css'],
  imports: [CommonModule, ReactiveFormsModule]
})
export class EmployeeProfileComponent implements OnInit {
  profileForm: FormGroup;
  loading = false;
  successMsg = '';
  errorMsg = '';

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.profileForm = this.fb.group({
      name: ['', Validators.required],
      specialization: ['', Validators.required],
      bio: ['']
    });
  }

  ngOnInit() {
    this.fetchEmployeeDetails();
  }

  getEmployeeId() {
    const token = localStorage.getItem('jwtToken');
    if (!token) return null;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.employeeId || payload.id || null;
    } catch {
      return null;
    }
  }

  fetchEmployeeDetails() {
    this.loading = true;
    const employeeId = this.getEmployeeId();
    this.http.get<any>(`/api/employees/${employeeId}`).subscribe({
      next: (res) => {
        this.profileForm.patchValue({
          name: res.name,
          specialization: res.specialization,
          bio: res.bio
        });
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load employee details.';
        this.loading = false;
      }
    });
  }

  updateEmployeeDetails() {
    if (this.profileForm.invalid) return;
    this.loading = true;
    const employeeId = this.getEmployeeId();
    this.http.put(`/api/employees/${employeeId}`, this.profileForm.value).subscribe({
      next: () => {
        this.successMsg = 'Profile updated successfully!';
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to update profile.';
        this.loading = false;
      }
    });
  }
}
