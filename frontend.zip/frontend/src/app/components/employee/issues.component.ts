import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-employee-issues',
  standalone: true,
  templateUrl: './issues.component.html',
  styleUrls: ['./issues.component.css'],
  imports: [CommonModule, FormsModule]
})
export class EmployeeIssuesComponent implements OnInit {
  issues: any[] = [];
  loading = false;
  errorMsg = '';

  selectedStatus: string = '';
  selectedDate: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchIssues();
  }

  getEmployeeId(): number | null {
    const employeeId = localStorage.getItem('employeeId');
    return employeeId ? parseInt(employeeId, 10) : null;
  }

  fetchIssues() {
    this.loading = true;
    const employeeId = this.getEmployeeId();
    if (!employeeId) {
      this.errorMsg = 'Employee ID not found.';
      this.loading = false;
      return;
    }
    this.http.get<any[]>(`/api/issues/employee/${employeeId}/all`).subscribe({
      next: (res) => {
        this.issues = (res || []).map(issue => ({
          ...issue,
          reportedTime: new Date(issue.reportedTime)
        }));
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load issues.';
        this.loading = false;
      }
    });
  }

  applyFilters() {
    const employeeId = this.getEmployeeId();
    if (!employeeId) {
      this.errorMsg = 'Employee ID not found.';
      return;
    }

    let url = `/api/issues/employee/${employeeId}/filter?`;
    if (this.selectedStatus) url += `status=${this.selectedStatus}&`;
    if (this.selectedDate) url += `date=${this.selectedDate}`;

    this.loading = true;
    this.http.get<any[]>(url).subscribe({
      next: (res) => {
        this.issues = (res || []).map(issue => ({
          ...issue,
          reportedTime: new Date(issue.reportedTime)
        }));
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to apply filters.';
        this.loading = false;
      }
    });
  }

  resetFilters() {
    this.selectedStatus = '';
    this.selectedDate = '';
    this.fetchIssues();
  }

  markAsResolved(id: number) {
    this.http.put(`/api/issues/${id}/resolve`, {}).subscribe({
      next: () => {
        this.fetchIssues(); // Refresh list after marking as resolved
      },
      error: () => {
        alert('Failed to mark issue as resolved.');
      }
    });
  }
}
