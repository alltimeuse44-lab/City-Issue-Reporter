
import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { AdminComponent } from './components/admin/admin.component';
import { AuthGuard } from './guards/auth.guard';
import { CitizenIssueComponent } from './components/citizen/citizen-issue.component';
import { CitizenComponent } from './components/citizen/citizen.component';
import { EmployeeIssuesComponent } from './components/employee/issues.component';
import { DashboardComponent } from './components/employee/dashboard.component';
import { PendingAppointmentsComponent } from './components/employee/pending-issues.component';
import { EmployeeProfileComponent } from './components/employee/employee-profile.component';


export const routes: Routes = [

  { path: 'citizen-issue', component: CitizenIssueComponent },
  { path: '', redirectTo: '/citizen', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegistrationComponent },
  {
    path: 'dashboard-admin',
    component: AdminComponent,
    canActivate: [AuthGuard],
    data: { roles: ['ADMIN'] }
  },
  {
    path: 'citizen',
    component: CitizenComponent,
    canActivate: [AuthGuard],
    data: { roles: ['CITIZEN'] },
    children: [
      { path: '', loadComponent: () => import('./components/citizen/citizen-dashboard.component').then(m => m.CitizenDashboardComponent) },
      { path: 'report', loadComponent: () => import('./components/citizen/report-issue.component').then(m => m.ReportIssueComponent) },
      { path: 'issues', loadComponent: () => import('./components/citizen/my-issues.component').then(m => m.MyIssuesComponent) },
      { path: 'profile', loadComponent: () => import('./components/citizen/edit-profile.component').then(m => m.EditProfileComponent) }
    ]
  },
  {
    path: 'employee',
    component: DashboardComponent,
    canActivate: [AuthGuard],
    data: { roles: ['EMPLOYEE'] },
    children: [
      { path: '', loadComponent: () => import('./components/employee/dashboard.component').then(m => m.DashboardComponent) },
      { path: 'pending-issues', loadComponent: () => import('./components/employee/pending-issues.component').then(m => m.PendingAppointmentsComponent) },
      { path: 'issues', loadComponent: () => import('./components/employee/issues.component').then(m => m.EmployeeIssuesComponent) },
      { path: 'profile', loadComponent: () => import('./components/employee/employee-profile.component').then(m => m.EmployeeProfileComponent) }
    ]
  },
  { path: '**', redirectTo: '' }
];
