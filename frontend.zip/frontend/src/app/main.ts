import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient } from '@angular/common/http';
// import { _LoginComponent } from ';
import { LoginComponent } from './components/login/login.component';
bootstrapApplication(LoginComponent, {
  providers: [provideHttpClient()]
});
