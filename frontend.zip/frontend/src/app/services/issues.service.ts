import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class IssuesService {
  constructor(private http: HttpClient) {}

  getAllIssues(): Observable<any[]> {
    return this.http.get<any[]>('/api/issues');
  }

  getIssuesByCitizen(citizenId: number): Observable<any[]> {
    return this.http.get<any[]>(`/api/issues/citizen/${citizenId}`);
  }

  reportIssue(payload: any): Observable<any> {
    return this.http.post('/api/issues', payload);
  }

  cancelIssue(issueId: number): Observable<any> {
    return this.http.put(`/api/issues/${issueId}/cancel`, {});
  }
}
