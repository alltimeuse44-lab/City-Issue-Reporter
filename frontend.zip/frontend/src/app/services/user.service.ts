import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class UserService {
  private apiUrl = 'http://localhost:8080/api/user';

  constructor(private http: HttpClient) {}

  getProfile(): Observable<any> {
    return this.http.get(`${this.apiUrl}/profile`);
  }

  getAllUsers(): Observable<any> {
    return this.http.get('http://localhost:8080/api/users');
  }

  deleteUser(id: string): Observable<any> {
    return this.http.delete(`http://localhost:8080/api/users/${id}`);
  }

  getAllDoctors(): Observable<any> {
    return this.http.get('http://localhost:8080/api/users/doctors');
  }
}
