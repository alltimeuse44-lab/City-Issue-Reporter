package com.city.issue.service;

import com.city.issue.entity.Issue;
import com.city.issue.entity.IssueHistory;
import com.city.issue.entity.IssueUpvote;
import com.city.issue.entity.Status;
import com.city.issue.repository.IssueHistoryRepository;
import com.city.issue.repository.IssueRepository;
import com.city.issue.repository.IssueUpvoteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class IssueService {

    private final IssueRepository issueRepository;
    private final IssueUpvoteRepository issueUpvoteRepository;
    private final IssueHistoryRepository issueHistoryRepository;

    public Issue createIssue(Issue issue) {
        issue.setStatus(Status.PENDING);
        return issueRepository.save(issue);
    }

    public List<Issue> getAllIssues() {
        return issueRepository.findAll();
    }

    public Issue getIssueById(Long id) {
        return issueRepository.findById(id).orElseThrow(() -> new RuntimeException("Issue not found"));
    }

    public List<Issue> getIssuesByUserId(Long userId) {
        return issueRepository.findByUserId(userId);
    }

    public List<Issue> getIssuesByStatus(Status status) {
        return issueRepository.findByStatus(status);
    }

    public Issue updateIssue(Long id, Issue updatedIssue) {
        Issue issue = getIssueById(id);
        String oldStatus = issue.getStatus().toString();
        String newStatus = updatedIssue.getStatus().toString();
        
        issue.setTitle(updatedIssue.getTitle());
        issue.setDescription(updatedIssue.getDescription());
        issue.setLocation(updatedIssue.getLocation());
        issue.setStatus(updatedIssue.getStatus());
        
        // Log status change if different
        if (!oldStatus.equals(newStatus)) {
            logIssueHistory(id, updatedIssue.getUserId(), "STATUS_CHANGE", oldStatus, newStatus, "Status updated");
        }
        
        return issueRepository.save(issue);
    }

    public void deleteIssue(Long id) {
        issueRepository.deleteById(id);
    }

    public Issue toggleUpvote(Long issueId, Long userId) {
        Issue issue = getIssueById(issueId);
        Optional<IssueUpvote> existingUpvote = issueUpvoteRepository.findByIssueIdAndUserId(issueId, userId);
        
        if (existingUpvote.isPresent()) {
            // Remove upvote
            issueUpvoteRepository.delete(existingUpvote.get());
        } else {
            // Add upvote
            IssueUpvote upvote = IssueUpvote.builder()
                    .issueId(issueId)
                    .userId(userId)
                    .build();
            issueUpvoteRepository.save(upvote);
        }
        
        // Update upvote count
        long upvoteCount = issueUpvoteRepository.countByIssueId(issueId);
        issue.setUpvotes((int) upvoteCount);
        return issueRepository.save(issue);
    }

    public List<IssueHistory> getIssueHistory(Long issueId) {
        return issueHistoryRepository.findByIssueIdOrderByTimestampDesc(issueId);
    }

    private void logIssueHistory(Long issueId, Long userId, String action, String oldStatus, String newStatus, String comment) {
        IssueHistory history = IssueHistory.builder()
                .issueId(issueId)
                .userId(userId)
                .action(action)
                .oldStatus(oldStatus)
                .newStatus(newStatus)
                .comment(comment)
                .timestamp(LocalDateTime.now())
                .build();
        issueHistoryRepository.save(history);
    }
}