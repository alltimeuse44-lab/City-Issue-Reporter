package com.city.issue.controller;

import com.city.issue.entity.Issue;
import com.city.issue.entity.IssueHistory;
import com.city.issue.entity.Status;
import com.city.issue.service.IssueService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/issues")
@RequiredArgsConstructor
public class IssueController {

    private final IssueService issueService;

    @PostMapping
    public Issue createIssue(@RequestBody Issue issue) {
        return issueService.createIssue(issue);
    }

    @GetMapping
    public List<Issue> getAllIssues() {
        return issueService.getAllIssues();
    }

    @GetMapping("/{id}")
    public Issue getIssueById(@PathVariable Long id) {
        return issueService.getIssueById(id);
    }

    @GetMapping("/user/{userId}")
    public List<Issue> getIssuesByUserId(@PathVariable Long userId) {
        return issueService.getIssuesByUserId(userId);
    }

    @GetMapping("/status/{status}")
    public List<Issue> getIssuesByStatus(@PathVariable Status status) {
        return issueService.getIssuesByStatus(status);
    }

    @PutMapping("/{id}")
    public Issue updateIssue(@PathVariable Long id, @RequestBody Issue issue) {
        return issueService.updateIssue(id, issue);
    }

    @DeleteMapping("/{id}")
    public void deleteIssue(@PathVariable Long id) {
        issueService.deleteIssue(id);
    }

    @PostMapping("/{id}/upvote")
    public Issue toggleUpvote(@PathVariable Long id, @RequestParam Long userId) {
        return issueService.toggleUpvote(id, userId);
    }

    @GetMapping("/{id}/history")
    public List<IssueHistory> getIssueHistory(@PathVariable Long id) {
        return issueService.getIssueHistory(id);
    }
}