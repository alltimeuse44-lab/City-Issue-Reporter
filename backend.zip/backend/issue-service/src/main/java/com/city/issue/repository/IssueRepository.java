package com.city.issue.repository;

import com.city.issue.entity.Issue;
import com.city.issue.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface IssueRepository extends JpaRepository<Issue, Long> {
    List<Issue> findByUserId(Long userId);
    List<Issue> findByStatus(Status status);
}
