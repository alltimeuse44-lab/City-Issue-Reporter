package com.city.issue.entity;

public enum Status {
    PENDING,
    IN_PROGRESS,
    RESOLVED,
    REJECTED
}
