package com.city.issue.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IssueHistory {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private Long issueId;
    private Long userId;
    private String action;
    private String oldStatus;
    private String newStatus;
    private String comment;
    private LocalDateTime timestamp;
}