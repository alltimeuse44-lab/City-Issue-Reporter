package com.city.issue.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IssueDTO {
    private String title;
    private String description;
    private String location;
    private String status; // e.g., PENDING, IN_PROGRESS, RESOLVED
    private Long userId;
}
