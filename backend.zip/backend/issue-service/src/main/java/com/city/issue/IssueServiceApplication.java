package com.city.issue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableDiscoveryClient
//@EnableFeignClients

public class IssueServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(IssueServiceApplication.class, args);
    }
}
