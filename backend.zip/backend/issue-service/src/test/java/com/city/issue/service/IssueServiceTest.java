package com.city.issue.service;

import com.city.issue.entity.Issue;
import com.city.issue.entity.IssueHistory;
import com.city.issue.entity.IssueUpvote;
import com.city.issue.entity.Status;
import com.city.issue.repository.IssueHistoryRepository;
import com.city.issue.repository.IssueRepository;
import com.city.issue.repository.IssueUpvoteRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IssueServiceTest {

    @Mock
    private IssueRepository issueRepository;

    @Mock
    private IssueUpvoteRepository issueUpvoteRepository;

    @Mock
    private IssueHistoryRepository issueHistoryRepository;

    @InjectMocks
    private IssueService issueService;

    private Issue testIssue;
    private List<Issue> issueList;
    private IssueUpvote testUpvote;
    private IssueHistory testHistory;

    @BeforeEach
    void setUp() {
        testIssue = Issue.builder()
                .id(1L)
                .title("Test Issue")
                .description("Test Description")
                .location("Test Location")
                .status(Status.PENDING)
                .userId(10L)
                .upvotes(0)
                .createdAt(LocalDateTime.now())
                .build();

        Issue resolvedIssue = Issue.builder()
                .id(2L)
                .title("Resolved Issue")
                .description("Resolved Description")
                .location("Resolved Location")
                .status(Status.RESOLVED)
                .userId(20L)
                .upvotes(5)
                .createdAt(LocalDateTime.now())
                .build();

        issueList = Arrays.asList(testIssue, resolvedIssue);

        testUpvote = IssueUpvote.builder()
                .id(1L)
                .issueId(1L)
                .userId(10L)
                .build();

        testHistory = IssueHistory.builder()
                .id(1L)
                .issueId(1L)
                .userId(10L)
                .action("STATUS_CHANGE")
                .oldStatus("PENDING")
                .newStatus("IN_PROGRESS")
                .comment("Status updated")
                .timestamp(LocalDateTime.now())
                .build();
    }

    @Test
    void createIssue_ShouldReturnIssueWithPendingStatus_WhenValidIssue() {
        // Given
        Issue newIssue = Issue.builder()
                .title("New Issue")
                .description("New Description")
                .location("New Location")
                .userId(10L)
                .build();

        Issue savedIssue = Issue.builder()
                .id(1L)
                .title("New Issue")
                .description("New Description")
                .location("New Location")
                .status(Status.PENDING)
                .userId(10L)
                .upvotes(0)
                .createdAt(LocalDateTime.now())
                .build();

        when(issueRepository.save(any(Issue.class))).thenReturn(savedIssue);

        // When
        Issue result = issueService.createIssue(newIssue);

        // Then
        assertNotNull(result);
        assertEquals("New Issue", result.getTitle());
        assertEquals(Status.PENDING, result.getStatus());
        assertEquals(1L, result.getId());
        verify(issueRepository, times(1)).save(any(Issue.class));
    }

    @Test
    void createIssue_ShouldSetPendingStatus_WhenStatusNotProvided() {
        // Given
        Issue newIssue = Issue.builder()
                .title("Issue Without Status")
                .description("Description")
                .location("Location")
                .userId(10L)
                .status(null)
                .build();

        Issue savedIssue = Issue.builder()
                .id(1L)
                .title("Issue Without Status")
                .description("Description")
                .location("Location")
                .status(Status.PENDING)
                .userId(10L)
                .build();

        when(issueRepository.save(any(Issue.class))).thenReturn(savedIssue);

        // When
        Issue result = issueService.createIssue(newIssue);

        // Then
        assertNotNull(result);
        assertEquals(Status.PENDING, result.getStatus());
        verify(issueRepository, times(1)).save(any(Issue.class));
    }

    @Test
    void getAllIssues_ShouldReturnAllIssues_WhenIssuesExist() {
        // Given
        when(issueRepository.findAll()).thenReturn(issueList);

        // When
        List<Issue> result = issueService.getAllIssues();

        // Then
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Test Issue", result.get(0).getTitle());
        assertEquals("Resolved Issue", result.get(1).getTitle());
        verify(issueRepository, times(1)).findAll();
    }

    @Test
    void getAllIssues_ShouldReturnEmptyList_WhenNoIssuesExist() {
        // Given
        when(issueRepository.findAll()).thenReturn(Arrays.asList());

        // When
        List<Issue> result = issueService.getAllIssues();

        // Then
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(issueRepository, times(1)).findAll();
    }

    @Test
    void getIssueById_ShouldReturnIssue_WhenIssueExists() {
        // Given
        when(issueRepository.findById(1L)).thenReturn(Optional.of(testIssue));

        // When
        Issue result = issueService.getIssueById(1L);

        // Then
        assertNotNull(result);
        assertEquals("Test Issue", result.getTitle());
        assertEquals(1L, result.getId());
        verify(issueRepository, times(1)).findById(1L);
    }

    @Test
    void getIssueById_ShouldThrowException_WhenIssueDoesNotExist() {
        // Given
        when(issueRepository.findById(999L)).thenReturn(Optional.empty());

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            issueService.getIssueById(999L);
        });

        assertEquals("Issue not found", exception.getMessage());
        verify(issueRepository, times(1)).findById(999L);
    }

    @Test
    void getIssuesByUserId_ShouldReturnUserIssues_WhenUserHasIssues() {
        // Given
        List<Issue> userIssues = Arrays.asList(testIssue);
        when(issueRepository.findByUserId(10L)).thenReturn(userIssues);

        // When
        List<Issue> result = issueService.getIssuesByUserId(10L);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(10L, result.get(0).getUserId());
        verify(issueRepository, times(1)).findByUserId(10L);
    }

    @Test
    void getIssuesByUserId_ShouldReturnEmptyList_WhenUserHasNoIssues() {
        // Given
        when(issueRepository.findByUserId(999L)).thenReturn(Arrays.asList());

        // When
        List<Issue> result = issueService.getIssuesByUserId(999L);

        // Then
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(issueRepository, times(1)).findByUserId(999L);
    }

    @Test
    void getIssuesByStatus_ShouldReturnIssuesWithStatus_WhenIssuesExist() {
        // Given
        List<Issue> pendingIssues = Arrays.asList(testIssue);
        when(issueRepository.findByStatus(Status.PENDING)).thenReturn(pendingIssues);

        // When
        List<Issue> result = issueService.getIssuesByStatus(Status.PENDING);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(Status.PENDING, result.get(0).getStatus());
        verify(issueRepository, times(1)).findByStatus(Status.PENDING);
    }

    @Test
    void getIssuesByStatus_ShouldReturnEmptyList_WhenNoIssuesWithStatus() {
        // Given
        when(issueRepository.findByStatus(Status.REJECTED)).thenReturn(Arrays.asList());

        // When
        List<Issue> result = issueService.getIssuesByStatus(Status.REJECTED);

        // Then
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(issueRepository, times(1)).findByStatus(Status.REJECTED);
    }

    @Test
    void updateIssue_ShouldUpdateIssueAndLogHistory_WhenStatusChanged() {
        // Given
        Issue updatedIssue = Issue.builder()
                .title("Updated Title")
                .description("Updated Description")
                .location("Updated Location")
                .status(Status.IN_PROGRESS)
                .userId(10L)
                .build();

        Issue savedIssue = Issue.builder()
                .id(1L)
                .title("Updated Title")
                .description("Updated Description")
                .location("Updated Location")
                .status(Status.IN_PROGRESS)
                .userId(10L)
                .build();

        when(issueRepository.findById(1L)).thenReturn(Optional.of(testIssue));
        when(issueRepository.save(any(Issue.class))).thenReturn(savedIssue);
        when(issueHistoryRepository.save(any(IssueHistory.class))).thenReturn(testHistory);

        // When
        Issue result = issueService.updateIssue(1L, updatedIssue);

        // Then
        assertNotNull(result);
        assertEquals("Updated Title", result.getTitle());
        assertEquals(Status.IN_PROGRESS, result.getStatus());
        verify(issueRepository, times(1)).findById(1L);
        verify(issueRepository, times(1)).save(any(Issue.class));
        verify(issueHistoryRepository, times(1)).save(any(IssueHistory.class));
    }

    @Test
    void updateIssue_ShouldUpdateIssueWithoutHistory_WhenStatusNotChanged() {
        // Given
        Issue updatedIssue = Issue.builder()
                .title("Updated Title Only")
                .description("Updated Description")
                .location("Updated Location")
                .status(Status.PENDING) // Same status
                .userId(10L)
                .build();

        Issue savedIssue = Issue.builder()
                .id(1L)
                .title("Updated Title Only")
                .description("Updated Description")
                .location("Updated Location")
                .status(Status.PENDING)
                .userId(10L)
                .build();

        when(issueRepository.findById(1L)).thenReturn(Optional.of(testIssue));
        when(issueRepository.save(any(Issue.class))).thenReturn(savedIssue);

        // When
        Issue result = issueService.updateIssue(1L, updatedIssue);

        // Then
        assertNotNull(result);
        assertEquals("Updated Title Only", result.getTitle());
        assertEquals(Status.PENDING, result.getStatus());
        verify(issueRepository, times(1)).findById(1L);
        verify(issueRepository, times(1)).save(any(Issue.class));
        verify(issueHistoryRepository, never()).save(any(IssueHistory.class));
    }

    @Test
    void updateIssue_ShouldHandleAllStatusTransitions() {
        // Test PENDING -> RESOLVED
        testStatusTransition(Status.PENDING, Status.RESOLVED);
        
        // Test IN_PROGRESS -> REJECTED
        testStatusTransition(Status.IN_PROGRESS, Status.REJECTED);
        
        // Test RESOLVED -> IN_PROGRESS (reopening)
        testStatusTransition(Status.RESOLVED, Status.IN_PROGRESS);
    }

    private void testStatusTransition(Status fromStatus, Status toStatus) {
        // Given
        Issue originalIssue = Issue.builder()
                .id(1L)
                .title("Test Issue")
                .description("Test Description")
                .location("Test Location")
                .status(fromStatus)
                .userId(10L)
                .build();

        Issue updatedIssue = Issue.builder()
                .title("Test Issue")
                .description("Test Description")
                .location("Test Location")
                .status(toStatus)
                .userId(10L)
                .build();

        when(issueRepository.findById(1L)).thenReturn(Optional.of(originalIssue));
        when(issueRepository.save(any(Issue.class))).thenReturn(updatedIssue);
        when(issueHistoryRepository.save(any(IssueHistory.class))).thenReturn(testHistory);

        // When
        Issue result = issueService.updateIssue(1L, updatedIssue);

        // Then
        assertNotNull(result);
        assertEquals(toStatus, result.getStatus());
        verify(issueHistoryRepository, times(1)).save(any(IssueHistory.class));
        
        // Reset mocks for next test
        reset(issueRepository, issueHistoryRepository);
    }

    @Test
    void deleteIssue_ShouldCallRepositoryDelete_WhenIssueIdProvided() {
        // Given
        doNothing().when(issueRepository).deleteById(1L);

        // When
        issueService.deleteIssue(1L);

        // Then
        verify(issueRepository, times(1)).deleteById(1L);
    }

    @Test
    void toggleUpvote_ShouldAddUpvote_WhenUserHasNotUpvoted() {
        // Given
        when(issueRepository.findById(1L)).thenReturn(Optional.of(testIssue));
        when(issueUpvoteRepository.findByIssueIdAndUserId(1L, 10L)).thenReturn(Optional.empty());
        when(issueUpvoteRepository.save(any(IssueUpvote.class))).thenReturn(testUpvote);
        when(issueUpvoteRepository.countByIssueId(1L)).thenReturn(1L);
        
        Issue updatedIssue = Issue.builder()
                .id(1L)
                .title("Test Issue")
                .description("Test Description")
                .location("Test Location")
                .status(Status.PENDING)
                .userId(10L)
                .upvotes(1)
                .build();
        
        when(issueRepository.save(any(Issue.class))).thenReturn(updatedIssue);

        // When
        Issue result = issueService.toggleUpvote(1L, 10L);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getUpvotes());
        verify(issueUpvoteRepository, times(1)).save(any(IssueUpvote.class));
        verify(issueUpvoteRepository, never()).delete(any(IssueUpvote.class));
        verify(issueRepository, times(1)).save(any(Issue.class));
    }

    @Test
    void toggleUpvote_ShouldRemoveUpvote_WhenUserHasAlreadyUpvoted() {
        // Given
        when(issueRepository.findById(1L)).thenReturn(Optional.of(testIssue));
        when(issueUpvoteRepository.findByIssueIdAndUserId(1L, 10L)).thenReturn(Optional.of(testUpvote));
        doNothing().when(issueUpvoteRepository).delete(testUpvote);
        when(issueUpvoteRepository.countByIssueId(1L)).thenReturn(0L);
        
        Issue updatedIssue = Issue.builder()
                .id(1L)
                .title("Test Issue")
                .description("Test Description")
                .location("Test Location")
                .status(Status.PENDING)
                .userId(10L)
                .upvotes(0)
                .build();
        
        when(issueRepository.save(any(Issue.class))).thenReturn(updatedIssue);

        // When
        Issue result = issueService.toggleUpvote(1L, 10L);

        // Then
        assertNotNull(result);
        assertEquals(0, result.getUpvotes());
        verify(issueUpvoteRepository, times(1)).delete(testUpvote);
        verify(issueUpvoteRepository, never()).save(any(IssueUpvote.class));
        verify(issueRepository, times(1)).save(any(Issue.class));
    }

    @Test
    void toggleUpvote_ShouldThrowException_WhenIssueNotFound() {
        // Given
        when(issueRepository.findById(999L)).thenReturn(Optional.empty());

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            issueService.toggleUpvote(999L, 10L);
        });

        assertEquals("Issue not found", exception.getMessage());
        verify(issueRepository, times(1)).findById(999L);
        verify(issueUpvoteRepository, never()).findByIssueIdAndUserId(anyLong(), anyLong());
    }

    @Test
    void getIssueHistory_ShouldReturnHistory_WhenHistoryExists() {
        // Given
        List<IssueHistory> historyList = Arrays.asList(testHistory);
        when(issueHistoryRepository.findByIssueIdOrderByTimestampDesc(1L)).thenReturn(historyList);

        // When
        List<IssueHistory> result = issueService.getIssueHistory(1L);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("STATUS_CHANGE", result.get(0).getAction());
        assertEquals("PENDING", result.get(0).getOldStatus());
        assertEquals("IN_PROGRESS", result.get(0).getNewStatus());
        verify(issueHistoryRepository, times(1)).findByIssueIdOrderByTimestampDesc(1L);
    }

    @Test
    void getIssueHistory_ShouldReturnEmptyList_WhenNoHistoryExists() {
        // Given
        when(issueHistoryRepository.findByIssueIdOrderByTimestampDesc(999L)).thenReturn(Arrays.asList());

        // When
        List<IssueHistory> result = issueService.getIssueHistory(999L);

        // Then
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(issueHistoryRepository, times(1)).findByIssueIdOrderByTimestampDesc(999L);
    }

    @Test
    void toggleUpvote_ShouldHandleMultipleUpvotes_WhenMultipleUsersUpvote() {
        // Given
        when(issueRepository.findById(1L)).thenReturn(Optional.of(testIssue));
        when(issueUpvoteRepository.findByIssueIdAndUserId(1L, 20L)).thenReturn(Optional.empty());
        when(issueUpvoteRepository.save(any(IssueUpvote.class))).thenReturn(testUpvote);
        when(issueUpvoteRepository.countByIssueId(1L)).thenReturn(5L); // Multiple upvotes
        
        Issue updatedIssue = Issue.builder()
                .id(1L)
                .title("Test Issue")
                .description("Test Description")
                .location("Test Location")
                .status(Status.PENDING)
                .userId(10L)
                .upvotes(5)
                .build();
        
        when(issueRepository.save(any(Issue.class))).thenReturn(updatedIssue);

        // When
        Issue result = issueService.toggleUpvote(1L, 20L);

        // Then
        assertNotNull(result);
        assertEquals(5, result.getUpvotes());
        verify(issueUpvoteRepository, times(1)).save(any(IssueUpvote.class));
        verify(issueRepository, times(1)).save(any(Issue.class));
    }

    @Test
    void createIssue_ShouldHandleNullFields_WhenSomeFieldsAreNull() {
        // Given
        Issue issueWithNulls = Issue.builder()
                .title("Title Only")
                .description(null)
                .location(null)
                .userId(10L)
                .build();

        Issue savedIssue = Issue.builder()
                .id(1L)
                .title("Title Only")
                .description(null)
                .location(null)
                .status(Status.PENDING)
                .userId(10L)
                .build();

        when(issueRepository.save(any(Issue.class))).thenReturn(savedIssue);

        // When
        Issue result = issueService.createIssue(issueWithNulls);

        // Then
        assertNotNull(result);
        assertEquals("Title Only", result.getTitle());
        assertNull(result.getDescription());
        assertNull(result.getLocation());
        assertEquals(Status.PENDING, result.getStatus());
        verify(issueRepository, times(1)).save(any(Issue.class));
    }
}