package com.city.issue.controller;

import com.city.issue.entity.Issue;
import com.city.issue.entity.IssueHistory;
import com.city.issue.entity.Status;
import com.city.issue.service.IssueService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
// import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(IssueController.class)
class IssueControllerTest {

    @Autowired
    private MockMvc mockMvc;

        // @MockBean is deprecated and not required for this test context
        @org.mockito.Mock
        private IssueService issueService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void createIssue_Success() throws Exception {
        Issue issue = Issue.builder()
                .id(1L)
                .title("Test Issue")
                .description("Test Description")
                .location("Test Location")
                .status(Status.PENDING)
                .userId(1L)
                .upvotes(0)
                .build();

        when(issueService.createIssue(any(Issue.class))).thenReturn(issue);

        mockMvc.perform(post("/api/issues")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(issue)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Test Issue"))
                .andExpect(jsonPath("$.status").value("PENDING"));
    }

    @Test
    void getAllIssues_Success() throws Exception {
        List<Issue> issues = Arrays.asList(
                Issue.builder().id(1L).title("Issue 1").status(Status.PENDING).build(),
                Issue.builder().id(2L).title("Issue 2").status(Status.RESOLVED).build()
        );

        when(issueService.getAllIssues()).thenReturn(issues);

        mockMvc.perform(get("/api/issues"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].title").value("Issue 1"));
    }

    @Test
    void getIssueById_Success() throws Exception {
        Issue issue = Issue.builder()
                .id(1L)
                .title("Test Issue")
                .status(Status.PENDING)
                .build();

        when(issueService.getIssueById(1L)).thenReturn(issue);

        mockMvc.perform(get("/api/issues/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Test Issue"));
    }

    @Test
    void getIssuesByUserId_Success() throws Exception {
        List<Issue> userIssues = Arrays.asList(
                Issue.builder().id(1L).title("User Issue").userId(1L).build()
        );

        when(issueService.getIssuesByUserId(1L)).thenReturn(userIssues);

        mockMvc.perform(get("/api/issues/user/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].title").value("User Issue"));
    }

    @Test
    void getIssuesByStatus_Success() throws Exception {
        List<Issue> pendingIssues = Arrays.asList(
                Issue.builder().id(1L).title("Pending Issue").status(Status.PENDING).build()
        );

        when(issueService.getIssuesByStatus(Status.PENDING)).thenReturn(pendingIssues);

        mockMvc.perform(get("/api/issues/status/PENDING"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }

    @Test
    void updateIssue_Success() throws Exception {
        Issue updatedIssue = Issue.builder()
                .id(1L)
                .title("Updated Issue")
                .status(Status.IN_PROGRESS)
                .build();

        when(issueService.updateIssue(anyLong(), any(Issue.class))).thenReturn(updatedIssue);

        mockMvc.perform(put("/api/issues/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedIssue)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Updated Issue"));
    }

    @Test
    void deleteIssue_Success() throws Exception {
        doNothing().when(issueService).deleteIssue(1L);

        mockMvc.perform(delete("/api/issues/1"))
                .andExpect(status().isOk());

        verify(issueService).deleteIssue(1L);
    }

    @Test
    void toggleUpvote_Success() throws Exception {
        Issue upvotedIssue = Issue.builder()
                .id(1L)
                .title("Test Issue")
                .upvotes(1)
                .build();

        when(issueService.toggleUpvote(1L, 2L)).thenReturn(upvotedIssue);

        mockMvc.perform(post("/api/issues/1/upvote")
                .param("userId", "2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.upvotes").value(1));
    }

    @Test
    void getIssueHistory_Success() throws Exception {
        List<IssueHistory> history = Arrays.asList(
                IssueHistory.builder()
                        .id(1L)
                        .issueId(1L)
                        .action("STATUS_CHANGE")
                        .timestamp(LocalDateTime.now())
                        .build()
        );

        when(issueService.getIssueHistory(1L)).thenReturn(history);

        mockMvc.perform(get("/api/issues/1/history"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].action").value("STATUS_CHANGE"));
    }
}