package com.city.user_service.service;

import com.city.user_service.entity.User;
import com.city.user_service.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    private User testUser;
    private List<User> userList;

    @BeforeEach
    void setUp() {
        testUser = User.builder()
                .id(1L)
                .name("Test User")
                .email("test@example.com")
                .phone("1234567890")
                .role("CITIZEN")
                .authUserId(10L)
                .build();

        User employee = User.builder()
                .id(2L)
                .name("Employee User")
                .email("emp@example.com")
                .phone("0987654321")
                .role("EMPLOYEE")
                .authUserId(20L)
                .build();

        userList = Arrays.asList(testUser, employee);
    }

    @Test
    void saveUser_ShouldReturnSavedUser_WhenValidUser() {
        // Given
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        // When
        User result = userService.saveUser(testUser);

        // Then
        assertNotNull(result);
        assertEquals("Test User", result.getName());
        assertEquals("test@example.com", result.getEmail());
        assertEquals("CITIZEN", result.getRole());
        verify(userRepository, times(1)).save(testUser);
    }

    @Test
    void saveUser_ShouldSetDefaultRole_WhenRoleIsNull() {
        // Given
        User userWithoutRole = User.builder()
                .name("Test User")
                .email("test@example.com")
                .phone("1234567890")
                .role(null)
                .authUserId(10L)
                .build();

        User savedUser = User.builder()
                .id(1L)
                .name("Test User")
                .email("test@example.com")
                .phone("1234567890")
                .role("CITIZEN")
                .authUserId(10L)
                .build();

        when(userRepository.save(any(User.class))).thenReturn(savedUser);

        // When
        User result = userService.saveUser(userWithoutRole);

        // Then
        assertNotNull(result);
        assertEquals("CITIZEN", result.getRole());
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    void saveUser_ShouldSetDefaultRole_WhenRoleIsBlank() {
        // Given
        User userWithBlankRole = User.builder()
                .name("Test User")
                .email("test@example.com")
                .phone("1234567890")
                .role("")
                .authUserId(10L)
                .build();

        User savedUser = User.builder()
                .id(1L)
                .name("Test User")
                .email("test@example.com")
                .phone("1234567890")
                .role("CITIZEN")
                .authUserId(10L)
                .build();

        when(userRepository.save(any(User.class))).thenReturn(savedUser);

        // When
        User result = userService.saveUser(userWithBlankRole);

        // Then
        assertNotNull(result);
        assertEquals("CITIZEN", result.getRole());
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    void saveUser_ShouldPreserveRole_WhenRoleIsProvided() {
        // Given
        User employeeUser = User.builder()
                .name("Employee User")
                .email("emp@example.com")
                .phone("1234567890")
                .role("EMPLOYEE")
                .authUserId(20L)
                .build();

        when(userRepository.save(any(User.class))).thenReturn(employeeUser);

        // When
        User result = userService.saveUser(employeeUser);

        // Then
        assertNotNull(result);
        assertEquals("EMPLOYEE", result.getRole());
        verify(userRepository, times(1)).save(employeeUser);
    }

    @Test
    void saveUser_ShouldHandleAdminRole_WhenRoleIsAdmin() {
        // Given
        User adminUser = User.builder()
                .name("Admin User")
                .email("admin@example.com")
                .phone("1234567890")
                .role("ADMIN")
                .authUserId(30L)
                .build();

        when(userRepository.save(any(User.class))).thenReturn(adminUser);

        // When
        User result = userService.saveUser(adminUser);

        // Then
        assertNotNull(result);
        assertEquals("ADMIN", result.getRole());
        verify(userRepository, times(1)).save(adminUser);
    }

    @Test
    void getAllUsers_ShouldReturnAllUsers_WhenUsersExist() {
        // Given
        when(userRepository.findAll()).thenReturn(userList);

        // When
        List<User> result = userService.getAllUsers();

        // Then
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Test User", result.get(0).getName());
        assertEquals("Employee User", result.get(1).getName());
        verify(userRepository, times(1)).findAll();
    }

    @Test
    void getAllUsers_ShouldReturnEmptyList_WhenNoUsersExist() {
        // Given
        when(userRepository.findAll()).thenReturn(Arrays.asList());

        // When
        List<User> result = userService.getAllUsers();

        // Then
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(userRepository, times(1)).findAll();
    }

    @Test
    void getUserById_ShouldReturnUser_WhenUserExists() {
        // Given
        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));

        // When
        Optional<User> result = userService.getUserById(1L);

        // Then
        assertTrue(result.isPresent());
        assertEquals("Test User", result.get().getName());
        assertEquals(1L, result.get().getId());
        verify(userRepository, times(1)).findById(1L);
    }

    @Test
    void getUserById_ShouldReturnEmpty_WhenUserDoesNotExist() {
        // Given
        when(userRepository.findById(999L)).thenReturn(Optional.empty());

        // When
        Optional<User> result = userService.getUserById(999L);

        // Then
        assertFalse(result.isPresent());
        verify(userRepository, times(1)).findById(999L);
    }

    @Test
    void getAllEmployees_ShouldReturnEmployees_WhenEmployeesExist() {
        // Given
        List<User> employees = Arrays.asList(
                User.builder().id(2L).name("Employee 1").role("EMPLOYEE").build(),
                User.builder().id(3L).name("Employee 2").role("EMPLOYEE").build()
        );
        when(userRepository.findByRole("EMPLOYEE")).thenReturn(employees);

        // When
        List<User> result = userService.getAllEmployees();

        // Then
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("EMPLOYEE", result.get(0).getRole());
        assertEquals("EMPLOYEE", result.get(1).getRole());
        verify(userRepository, times(1)).findByRole("EMPLOYEE");
    }

    @Test
    void getAllEmployees_ShouldReturnEmptyList_WhenNoEmployeesExist() {
        // Given
        when(userRepository.findByRole("EMPLOYEE")).thenReturn(Arrays.asList());

        // When
        List<User> result = userService.getAllEmployees();

        // Then
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(userRepository, times(1)).findByRole("EMPLOYEE");
    }

    @Test
    void getUserByAuthUserId_ShouldReturnUser_WhenUserExists() {
        // Given
        when(userRepository.findByAuthUserId(10L)).thenReturn(Optional.of(testUser));

        // When
        Optional<User> result = userService.getUserByAuthUserId(10L);

        // Then
        assertTrue(result.isPresent());
        assertEquals(10L, result.get().getAuthUserId());
        assertEquals("Test User", result.get().getName());
        verify(userRepository, times(1)).findByAuthUserId(10L);
    }

    @Test
    void getUserByAuthUserId_ShouldReturnEmpty_WhenUserDoesNotExist() {
        // Given
        when(userRepository.findByAuthUserId(999L)).thenReturn(Optional.empty());

        // When
        Optional<User> result = userService.getUserByAuthUserId(999L);

        // Then
        assertFalse(result.isPresent());
        verify(userRepository, times(1)).findByAuthUserId(999L);
    }

    @Test
    void updateProfile_ShouldUpdateAllFields_WhenAllFieldsProvided() {
        // Given
        User profileUpdate = User.builder()
                .name("Updated Name")
                .email("updated@example.com")
                .phone("9999999999")
                .build();

        User updatedUser = User.builder()
                .id(1L)
                .name("Updated Name")
                .email("updated@example.com")
                .phone("9999999999")
                .role("CITIZEN")
                .authUserId(10L)
                .build();

        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(updatedUser);

        // When
        Optional<User> result = userService.updateProfile(1L, profileUpdate);

        // Then
        assertTrue(result.isPresent());
        assertEquals("Updated Name", result.get().getName());
        assertEquals("updated@example.com", result.get().getEmail());
        assertEquals("9999999999", result.get().getPhone());
        verify(userRepository, times(1)).findById(1L);
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    void updateProfile_ShouldUpdateOnlyProvidedFields_WhenPartialUpdate() {
        // Given
        User profileUpdate = User.builder()
                .name("Updated Name Only")
                .email(null)
                .phone(null)
                .build();

        User updatedUser = User.builder()
                .id(1L)
                .name("Updated Name Only")
                .email("test@example.com") // Original email preserved
                .phone("1234567890") // Original phone preserved
                .role("CITIZEN")
                .authUserId(10L)
                .build();

        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(updatedUser);

        // When
        Optional<User> result = userService.updateProfile(1L, profileUpdate);

        // Then
        assertTrue(result.isPresent());
        assertEquals("Updated Name Only", result.get().getName());
        assertEquals("test@example.com", result.get().getEmail()); // Original preserved
        assertEquals("1234567890", result.get().getPhone()); // Original preserved
        verify(userRepository, times(1)).findById(1L);
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    void updateProfile_ShouldReturnEmpty_WhenUserDoesNotExist() {
        // Given
        User profileUpdate = User.builder()
                .name("Updated Name")
                .build();

        when(userRepository.findById(999L)).thenReturn(Optional.empty());

        // When
        Optional<User> result = userService.updateProfile(999L, profileUpdate);

        // Then
        assertFalse(result.isPresent());
        verify(userRepository, times(1)).findById(999L);
        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void updateProfile_ShouldHandleNullProfileUpdate_WhenProfileUpdateIsNull() {
        // Given
        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        // When
        Optional<User> result = userService.updateProfile(1L, null);

        // Then
        assertTrue(result.isPresent());
        // Original values should be preserved since no updates provided
        assertEquals("Test User", result.get().getName());
        assertEquals("test@example.com", result.get().getEmail());
        verify(userRepository, times(1)).findById(1L);
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    void deleteUser_ShouldCallRepositoryDelete_WhenUserIdProvided() {
        // Given
        doNothing().when(userRepository).deleteById(1L);

        // When
        userService.deleteUser(1L);

        // Then
        verify(userRepository, times(1)).deleteById(1L);
    }

    @Test
    void deleteUser_ShouldHandleNonExistentUser_WhenUserDoesNotExist() {
        // Given
        doThrow(new RuntimeException("User not found")).when(userRepository).deleteById(999L);

        // When & Then
        assertThrows(RuntimeException.class, () -> {
            userService.deleteUser(999L);
        });

        verify(userRepository, times(1)).deleteById(999L);
    }

    @Test
    void saveUser_ShouldHandleNullUser_WhenUserIsNull() {
        // Given
        when(userRepository.save(any())).thenThrow(new IllegalArgumentException("User cannot be null"));

        // When & Then
        assertThrows(IllegalArgumentException.class, () -> {
            userService.saveUser(null);
        });

        verify(userRepository, times(1)).save(any());
    }

    @Test
    void updateProfile_ShouldUpdateEmailOnly_WhenOnlyEmailProvided() {
        // Given
        User profileUpdate = User.builder()
                .email("newemail@example.com")
                .build();

        User updatedUser = User.builder()
                .id(1L)
                .name("Test User") // Original preserved
                .email("newemail@example.com")
                .phone("1234567890") // Original preserved
                .role("CITIZEN")
                .authUserId(10L)
                .build();

        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(updatedUser);

        // When
        Optional<User> result = userService.updateProfile(1L, profileUpdate);

        // Then
        assertTrue(result.isPresent());
        assertEquals("Test User", result.get().getName()); // Original preserved
        assertEquals("newemail@example.com", result.get().getEmail());
        assertEquals("1234567890", result.get().getPhone()); // Original preserved
        verify(userRepository, times(1)).findById(1L);
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    void updateProfile_ShouldUpdatePhoneOnly_WhenOnlyPhoneProvided() {
        // Given
        User profileUpdate = User.builder()
                .phone("5555555555")
                .build();

        User updatedUser = User.builder()
                .id(1L)
                .name("Test User") // Original preserved
                .email("test@example.com") // Original preserved
                .phone("5555555555")
                .role("CITIZEN")
                .authUserId(10L)
                .build();

        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(updatedUser);

        // When
        Optional<User> result = userService.updateProfile(1L, profileUpdate);

        // Then
        assertTrue(result.isPresent());
        assertEquals("Test User", result.get().getName()); // Original preserved
        assertEquals("test@example.com", result.get().getEmail()); // Original preserved
        assertEquals("5555555555", result.get().getPhone());
        verify(userRepository, times(1)).findById(1L);
        verify(userRepository, times(1)).save(any(User.class));
    }
}