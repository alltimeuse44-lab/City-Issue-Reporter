package com.city.user_service.controller;

import com.city.user_service.entity.User;
import com.city.user_service.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper;
    private User testUser;
    private List<User> userList;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
        objectMapper = new ObjectMapper();
        
        testUser = User.builder()
                .id(1L)
                .name("Test User")
                .email("test@example.com")
                .phone("1234567890")
                .role("CITIZEN")
                .authUserId(10L)
                .build();

        User employee = User.builder()
                .id(2L)
                .name("Employee User")
                .email("emp@example.com")
                .phone("0987654321")
                .role("EMPLOYEE")
                .authUserId(20L)
                .build();

        userList = Arrays.asList(testUser, employee);
    }

    @Test
    void addUser_ShouldReturnUser_WhenValidUser() throws Exception {
        // Given
        when(userService.saveUser(any(User.class))).thenReturn(testUser);

        // When & Then
        mockMvc.perform(post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testUser)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("Test User"))
                .andExpect(jsonPath("$.email").value("test@example.com"))
                .andExpect(jsonPath("$.role").value("CITIZEN"));

        verify(userService, times(1)).saveUser(any(User.class));
    }

    @Test
    void addUser_ShouldHandleNullFields_WhenUserHasNullFields() throws Exception {
        // Given
        User userWithNulls = User.builder()
                .name(null)
                .email("test@example.com")
                .phone(null)
                .role("CITIZEN")
                .build();

        User savedUser = User.builder()
                .id(1L)
                .name(null)
                .email("test@example.com")
                .phone(null)
                .role("CITIZEN")
                .build();

        when(userService.saveUser(any(User.class))).thenReturn(savedUser);

        // When & Then
        mockMvc.perform(post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(userWithNulls)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("test@example.com"))
                .andExpect(jsonPath("$.role").value("CITIZEN"));

        verify(userService, times(1)).saveUser(any(User.class));
    }

    @Test
    void getAllUsers_ShouldReturnUserList_WhenUsersExist() throws Exception {
        // Given
        when(userService.getAllUsers()).thenReturn(userList);

        // When & Then
        mockMvc.perform(get("/api/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].name").value("Test User"))
                .andExpect(jsonPath("$[1].name").value("Employee User"));

        verify(userService, times(1)).getAllUsers();
    }

    @Test
    void getAllUsers_ShouldReturnEmptyList_WhenNoUsersExist() throws Exception {
        // Given
        when(userService.getAllUsers()).thenReturn(Arrays.asList());

        // When & Then
        mockMvc.perform(get("/api/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));

        verify(userService, times(1)).getAllUsers();
    }

    @Test
    void getAllUsers_ShouldReturnInternalServerError_WhenServiceThrowsException() throws Exception {
        // Given
        when(userService.getAllUsers()).thenThrow(new RuntimeException("Database error"));

        // When & Then
        mockMvc.perform(get("/api/users"))
                .andExpect(status().isInternalServerError());

        verify(userService, times(1)).getAllUsers();
    }

    @Test
    void getUserById_ShouldReturnUser_WhenUserExists() throws Exception {
        // Given
        when(userService.getUserById(1L)).thenReturn(Optional.of(testUser));

        // When & Then
        mockMvc.perform(get("/api/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("Test User"))
                .andExpect(jsonPath("$.email").value("test@example.com"));

        verify(userService, times(1)).getUserById(1L);
    }

    @Test
    void getUserById_ShouldReturnNotFound_WhenUserDoesNotExist() throws Exception {
        // Given
        when(userService.getUserById(999L)).thenReturn(Optional.empty());

        // When & Then
        mockMvc.perform(get("/api/users/999"))
                .andExpect(status().isNotFound());

        verify(userService, times(1)).getUserById(999L);
    }

    @Test
    void getAllEmployees_ShouldReturnEmployeeList_WhenEmployeesExist() throws Exception {
        // Given
        List<User> employees = Arrays.asList(
                User.builder().id(2L).name("Employee 1").role("EMPLOYEE").build(),
                User.builder().id(3L).name("Employee 2").role("EMPLOYEE").build()
        );
        when(userService.getAllEmployees()).thenReturn(employees);

        // When & Then
        mockMvc.perform(get("/api/users/employees"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].role").value("EMPLOYEE"))
                .andExpect(jsonPath("$[1].role").value("EMPLOYEE"));

        verify(userService, times(1)).getAllEmployees();
    }

    @Test
    void getAllEmployees_ShouldReturnEmptyList_WhenNoEmployeesExist() throws Exception {
        // Given
        when(userService.getAllEmployees()).thenReturn(Arrays.asList());

        // When & Then
        mockMvc.perform(get("/api/users/employees"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));

        verify(userService, times(1)).getAllEmployees();
    }

    @Test
    void getUserByAuthUserId_ShouldReturnUser_WhenUserExists() throws Exception {
        // Given
        when(userService.getUserByAuthUserId(10L)).thenReturn(Optional.of(testUser));

        // When & Then
        mockMvc.perform(get("/api/users/auth/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.authUserId").value(10))
                .andExpect(jsonPath("$.name").value("Test User"));

        verify(userService, times(1)).getUserByAuthUserId(10L);
    }

    @Test
    void getUserByAuthUserId_ShouldReturnNotFound_WhenUserDoesNotExist() throws Exception {
        // Given
        when(userService.getUserByAuthUserId(999L)).thenReturn(Optional.empty());

        // When & Then
        mockMvc.perform(get("/api/users/auth/999"))
                .andExpect(status().isNotFound());

        verify(userService, times(1)).getUserByAuthUserId(999L);
    }

    @Test
    void updateProfile_ShouldReturnUpdatedUser_WhenUserExists() throws Exception {
        // Given
        User profileUpdate = User.builder()
                .name("Updated Name")
                .email("updated@example.com")
                .phone("9999999999")
                .build();

        User updatedUser = User.builder()
                .id(1L)
                .name("Updated Name")
                .email("updated@example.com")
                .phone("9999999999")
                .role("CITIZEN")
                .authUserId(10L)
                .build();

        when(userService.updateProfile(eq(1L), any(User.class))).thenReturn(Optional.of(updatedUser));

        // When & Then
        mockMvc.perform(put("/api/users/1/profile")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(profileUpdate)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Updated Name"))
                .andExpect(jsonPath("$.email").value("updated@example.com"))
                .andExpect(jsonPath("$.phone").value("9999999999"));

        verify(userService, times(1)).updateProfile(eq(1L), any(User.class));
    }

    @Test
    void updateProfile_ShouldReturnNotFound_WhenUserDoesNotExist() throws Exception {
        // Given
        User profileUpdate = User.builder()
                .name("Updated Name")
                .email("updated@example.com")
                .build();

        when(userService.updateProfile(eq(999L), any(User.class))).thenReturn(Optional.empty());

        // When & Then
        mockMvc.perform(put("/api/users/999/profile")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(profileUpdate)))
                .andExpect(status().isNotFound());

        verify(userService, times(1)).updateProfile(eq(999L), any(User.class));
    }

    @Test
    void updateProfile_ShouldHandlePartialUpdate_WhenOnlySomeFieldsProvided() throws Exception {
        // Given
        User partialUpdate = User.builder()
                .name("New Name Only")
                .build();

        User updatedUser = User.builder()
                .id(1L)
                .name("New Name Only")
                .email("test@example.com") // Original email preserved
                .phone("1234567890") // Original phone preserved
                .role("CITIZEN")
                .authUserId(10L)
                .build();

        when(userService.updateProfile(eq(1L), any(User.class))).thenReturn(Optional.of(updatedUser));

        // When & Then
        mockMvc.perform(put("/api/users/1/profile")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(partialUpdate)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("New Name Only"))
                .andExpect(jsonPath("$.email").value("test@example.com"));

        verify(userService, times(1)).updateProfile(eq(1L), any(User.class));
    }

    @Test
    void deleteUser_ShouldReturnOk_WhenUserDeleted() throws Exception {
        // Given
        doNothing().when(userService).deleteUser(1L);

        // When & Then
        mockMvc.perform(delete("/api/users/1"))
                .andExpect(status().isOk());

        verify(userService, times(1)).deleteUser(1L);
    }

    @Test
    void deleteUser_ShouldReturnInternalServerError_WhenServiceThrowsException() throws Exception {
        // Given
        doThrow(new RuntimeException("Delete failed")).when(userService).deleteUser(1L);

        // When & Then
        mockMvc.perform(delete("/api/users/1"))
                .andExpect(status().isInternalServerError());

        verify(userService, times(1)).deleteUser(1L);
    }

    @Test
    void addUser_ShouldHandleEmployeeRole_WhenRoleIsEmployee() throws Exception {
        // Given
        User employeeUser = User.builder()
                .name("Employee User")
                .email("emp@example.com")
                .phone("1234567890")
                .role("EMPLOYEE")
                .authUserId(20L)
                .build();

        User savedEmployee = User.builder()
                .id(2L)
                .name("Employee User")
                .email("emp@example.com")
                .phone("1234567890")
                .role("EMPLOYEE")
                .authUserId(20L)
                .build();

        when(userService.saveUser(any(User.class))).thenReturn(savedEmployee);

        // When & Then
        mockMvc.perform(post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(employeeUser)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.role").value("EMPLOYEE"))
                .andExpect(jsonPath("$.authUserId").value(20));

        verify(userService, times(1)).saveUser(any(User.class));
    }

    @Test
    void addUser_ShouldHandleAdminRole_WhenRoleIsAdmin() throws Exception {
        // Given
        User adminUser = User.builder()
                .name("Admin User")
                .email("admin@example.com")
                .phone("1234567890")
                .role("ADMIN")
                .authUserId(30L)
                .build();

        User savedAdmin = User.builder()
                .id(3L)
                .name("Admin User")
                .email("admin@example.com")
                .phone("1234567890")
                .role("ADMIN")
                .authUserId(30L)
                .build();

        when(userService.saveUser(any(User.class))).thenReturn(savedAdmin);

        // When & Then
        mockMvc.perform(post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(adminUser)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.role").value("ADMIN"))
                .andExpect(jsonPath("$.authUserId").value(30));

        verify(userService, times(1)).saveUser(any(User.class));
    }

    @Test
    void deleteUser_ShouldHandleNonExistentUser_WhenUserDoesNotExist() throws Exception {
        // Given
        doThrow(new RuntimeException("User not found")).when(userService).deleteUser(999L);

        // When & Then
        mockMvc.perform(delete("/api/users/999"))
                .andExpect(status().isInternalServerError());

        verify(userService, times(1)).deleteUser(999L);
    }
}