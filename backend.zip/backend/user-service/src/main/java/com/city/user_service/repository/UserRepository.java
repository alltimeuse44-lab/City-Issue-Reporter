package com.city.user_service.repository;

import com.city.user_service.entity.User;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
	List<User> findByRole(String role);
	Optional<User> findByAuthUserId(Long authUserId);
}
