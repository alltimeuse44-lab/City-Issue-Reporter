package com.city.user_service.service;

import com.city.user_service.entity.User;
import com.city.user_service.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;

    public User saveUser(User user) {
        // If role not provided, assign default role
        if (user.getRole() == null || user.getRole().isBlank()) {
            user.setRole("CITIZEN"); //  default role
        }
        return userRepository.save(user);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    public List<User> getAllEmployees() {
        return userRepository.findByRole("EMPLOYEE");
    }

    public Optional<User> getUserByAuthUserId(Long authUserId) {
        return userRepository.findByAuthUserId(authUserId);
    }

    public Optional<User> updateProfile(Long id, User profileUpdate) {
        return userRepository.findById(id).map(user -> {
            if (profileUpdate.getName() != null) {
                user.setName(profileUpdate.getName());
            }
            if (profileUpdate.getEmail() != null) {
                user.setEmail(profileUpdate.getEmail());
            }
            if (profileUpdate.getPhone() != null) {
                user.setPhone(profileUpdate.getPhone());
            }
            return userRepository.save(user);
        });
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}
