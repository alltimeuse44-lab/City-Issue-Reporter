package com.clinic.eureka_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
