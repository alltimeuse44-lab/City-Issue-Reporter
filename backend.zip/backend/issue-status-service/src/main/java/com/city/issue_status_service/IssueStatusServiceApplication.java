package com.city.issue_status_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IssueStatusServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(IssueStatusServiceApplication.class, args);
    }
}
