package com.city.issue_status_service.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IssueStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long issueId;
    private String status; // e.g., Pending, In Progress, Resolved, Rejected
    private Boolean isVerified;
    private LocalDateTime timestamp;
}
