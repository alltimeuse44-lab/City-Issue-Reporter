package com.city.issue_status_service.controller;

import com.city.issue_status_service.entity.IssueStatus;
import com.city.issue_status_service.service.IssueStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/issue-status")
public class IssueStatusController {

    @Autowired
    private IssueStatusService issueStatusService;

    @PostMapping
    public IssueStatus createStatus(@RequestBody IssueStatus status) {
        return issueStatusService.createStatus(status);
    }

    @GetMapping("/issue/{issueId}")
    public List<IssueStatus> getStatusByIssue(@PathVariable Long issueId) {
        return issueStatusService.getStatusByIssueId(issueId);
    }

    @PutMapping("/{id}/verify")
    public IssueStatus updateVerification(@PathVariable Long id, @RequestParam Boolean isVerified) {
        return issueStatusService.updateVerification(id, isVerified);
    }
    
    @PutMapping("/{id}/status")
    public IssueStatus updateStatus(@PathVariable Long id, @RequestParam String status) {
    	return issueStatusService.updateStatus(id, status);
    }
}