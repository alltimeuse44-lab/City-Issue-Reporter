package com.city.issue_status_service.service;

import com.city.issue_status_service.entity.IssueStatus;

import java.util.List;

public interface IssueStatusService {
    IssueStatus createStatus(IssueStatus status);
    List<IssueStatus> getStatusByIssueId(Long issueId);
    IssueStatus updateVerification(Long statusId, Boolean isVerified);
        IssueStatus updateStatus(Long statusId, String status);
}
