package com.city.issue_status_service.repository;

import com.city.issue_status_service.entity.IssueStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IssueStatusRepository extends JpaRepository<IssueStatus, Long> {
    List<IssueStatus> findByIssueId(Long issueId);
}
