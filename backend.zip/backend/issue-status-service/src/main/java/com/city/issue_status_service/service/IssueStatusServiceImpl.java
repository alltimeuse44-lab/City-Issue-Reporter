package com.city.issue_status_service.service;

import com.city.issue_status_service.entity.IssueStatus;
import com.city.issue_status_service.repository.IssueStatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class IssueStatusServiceImpl implements IssueStatusService {

    @Autowired
    private IssueStatusRepository repository;

    @Override
    public IssueStatus createStatus(IssueStatus status) {
        status.setTimestamp(LocalDateTime.now());
        return repository.save(status);
    }

    @Override
    public List<IssueStatus> getStatusByIssueId(Long issueId) {
        return repository.findByIssueId(issueId);
    }

    @Override
    public IssueStatus updateVerification(Long statusId, Boolean isVerified) {
        IssueStatus status = repository.findById(statusId)
                .orElseThrow(() -> new RuntimeException("IssueStatus not found"));
        status.setIsVerified(isVerified);
        return repository.save(status);
    }
        @Override
        public IssueStatus updateStatus(Long statusId, String status) {
            IssueStatus issueStatus = repository.findById(statusId)
                    .orElseThrow(() -> new RuntimeException("IssueStatus not found"));
            issueStatus.setStatus(status);
            return repository.save(issueStatus);
        }
}
