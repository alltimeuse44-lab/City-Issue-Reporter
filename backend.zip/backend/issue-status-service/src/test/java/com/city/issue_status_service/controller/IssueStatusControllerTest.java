package com.city.issue_status_service.controller;

import com.city.issue_status_service.entity.IssueStatus;
import com.city.issue_status_service.service.IssueStatusService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(IssueStatusController.class)
class IssueStatusControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IssueStatusService issueStatusService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void createStatus_Success() throws Exception {
        IssueStatus status = IssueStatus.builder()
                .id(1L)
                .issueId(1L)
                .status("PENDING")
                .isVerified(false)
                .timestamp(LocalDateTime.now())
                .build();

        when(issueStatusService.createStatus(any(IssueStatus.class))).thenReturn(status);

        mockMvc.perform(post("/api/issue-status")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(status)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("PENDING"))
                .andExpect(jsonPath("$.issueId").value(1));
    }

    @Test
    void getStatusByIssueId_Success() throws Exception {
        List<IssueStatus> statusList = Arrays.asList(
                IssueStatus.builder()
                        .id(1L)
                        .issueId(1L)
                        .status("PENDING")
                        .isVerified(false)
                        .timestamp(LocalDateTime.now())
                        .build()
        );

        when(issueStatusService.getStatusByIssueId(1L)).thenReturn(statusList);

        mockMvc.perform(get("/api/issue-status/issue/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].status").value("PENDING"));
    }

    @Test
    void updateVerification_Success() throws Exception {
        IssueStatus updatedStatus = IssueStatus.builder()
                .id(1L)
                .issueId(1L)
                .status("PENDING")
                .isVerified(true)
                .timestamp(LocalDateTime.now())
                .build();

        when(issueStatusService.updateVerification(anyLong(), any(Boolean.class))).thenReturn(updatedStatus);

        mockMvc.perform(put("/api/issue-status/1/verify")
                .param("isVerified", "true"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.isVerified").value(true));
    }

    @Test
    void updateStatus_Success() throws Exception {
        IssueStatus updatedStatus = IssueStatus.builder()
                .id(1L)
                .issueId(1L)
                .status("IN_PROGRESS")
                .isVerified(false)
                .timestamp(LocalDateTime.now())
                .build();

        when(issueStatusService.updateStatus(anyLong(), any(String.class))).thenReturn(updatedStatus);

        mockMvc.perform(put("/api/issue-status/1")
                .param("status", "IN_PROGRESS"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("IN_PROGRESS"));
    }
}