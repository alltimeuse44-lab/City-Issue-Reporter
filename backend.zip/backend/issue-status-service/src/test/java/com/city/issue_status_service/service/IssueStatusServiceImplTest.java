package com.city.issue_status_service.service;

import com.city.issue_status_service.entity.IssueStatus;
import com.city.issue_status_service.repository.IssueStatusRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IssueStatusServiceImplTest {

    @Mock
    private IssueStatusRepository issueStatusRepository;

    @InjectMocks
    private IssueStatusServiceImpl issueStatusService;

    private IssueStatus issueStatus;

    @BeforeEach
    void setUp() {
        issueStatus = IssueStatus.builder()
                .id(1L)
                .issueId(1L)
                .status("PENDING")
                .isVerified(false)
                .timestamp(LocalDateTime.now())
                .build();
    }

    @Test
    void createStatus_Success() {
        when(issueStatusRepository.save(any(IssueStatus.class))).thenReturn(issueStatus);

        IssueStatus result = issueStatusService.createStatus(issueStatus);

        assertNotNull(result);
        assertEquals("PENDING", result.getStatus());
        assertEquals(1L, result.getIssueId());
        verify(issueStatusRepository).save(issueStatus);
    }

    @Test
    void getStatusByIssueId_Success() {
        List<IssueStatus> statusList = Arrays.asList(issueStatus);
        when(issueStatusRepository.findByIssueId(1L)).thenReturn(statusList);

        List<IssueStatus> result = issueStatusService.getStatusByIssueId(1L);

        assertEquals(1, result.size());
        assertEquals("PENDING", result.get(0).getStatus());
        verify(issueStatusRepository).findByIssueId(1L);
    }

    @Test
    void updateVerification_Success() {
        when(issueStatusRepository.findById(1L)).thenReturn(Optional.of(issueStatus));
        when(issueStatusRepository.save(any(IssueStatus.class))).thenReturn(issueStatus);

        IssueStatus result = issueStatusService.updateVerification(1L, true);

        assertNotNull(result);
        assertTrue(result.getIsVerified());
        verify(issueStatusRepository).findById(1L);
        verify(issueStatusRepository).save(any(IssueStatus.class));
    }

    @Test
    void updateVerification_NotFound() {
        when(issueStatusRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> {
            issueStatusService.updateVerification(1L, true);
        });
    }

    @Test
    void updateStatus_Success() {
        when(issueStatusRepository.findById(1L)).thenReturn(Optional.of(issueStatus));
        when(issueStatusRepository.save(any(IssueStatus.class))).thenReturn(issueStatus);

        IssueStatus result = issueStatusService.updateStatus(1L, "IN_PROGRESS");

        assertNotNull(result);
        assertEquals("IN_PROGRESS", result.getStatus());
        verify(issueStatusRepository).findById(1L);
        verify(issueStatusRepository).save(any(IssueStatus.class));
    }

    @Test
    void updateStatus_NotFound() {
        when(issueStatusRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> {
            issueStatusService.updateStatus(1L, "IN_PROGRESS");
        });
    }
}