package com.city.authservice.service;

import com.city.authservice.dto.*;
import com.city.authservice.entity.Role;
import com.city.authservice.entity.User;
import com.city.authservice.feignClient.UserClient;
import com.city.authservice.repository.UserRepository;
import com.city.authservice.security.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Collections;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private AuthenticationManager authenticationManager;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private CustomUserDetailsService userDetailsService;

    @Mock
    private UserClient userClient;

    @InjectMocks
    private AuthService authService;

    private RegisterRequest registerRequest;
    private LoginRequest loginRequest;
    private User user;
    private UserDetails userDetails;

    @BeforeEach
    void setUp() {
        registerRequest = RegisterRequest.builder()
                .username("testuser")
                .email("test@example.com")
                .password("password123")
                .phone("1234567890")
                .role(Role.CITIZEN)
                .build();

        loginRequest = LoginRequest.builder()
                .username("testuser")
                .password("password123")
                .build();

        user = User.builder()
                .id(1L)
                .username("testuser")
                .email("test@example.com")
                .password("encodedPassword")
                .role(Role.CITIZEN)
                .build();

        userDetails = new org.springframework.security.core.userdetails.User(
                "testuser",
                "encodedPassword",
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_CITIZEN"))
        );
    }

    @Test
    void register_ShouldReturnAuthResponse_WhenValidRequest() {
        // Given
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(user);
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(userDetails);
        when(jwtUtil.generateToken(anyString(), anyString(), any(Long.class))).thenReturn("jwt-token");
        when(userClient.createUser(any(com.city.authservice.dto.User.class)))
                .thenReturn(com.city.authservice.dto.User.builder().build());

        // When
        AuthResponse response = authService.register(registerRequest);

        // Then
        assertNotNull(response);
        assertEquals("jwt-token", response.getToken());
        assertEquals(Role.CITIZEN, response.getRole());
        assertEquals(1L, response.getUserId());

        verify(userRepository, times(1)).save(any(User.class));
        verify(userClient, times(1)).createUser(any(com.city.authservice.dto.User.class));
        verify(jwtUtil, times(1)).generateToken(anyString(), anyString(), any(Long.class));
    }

    @Test
    void register_ShouldDefaultToCitizen_WhenRoleIsNull() {
        // Given
        registerRequest.setRole(null);
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(user);
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(userDetails);
        when(jwtUtil.generateToken(anyString(), anyString(), any(Long.class))).thenReturn("jwt-token");
        when(userClient.createUser(any(com.city.authservice.dto.User.class)))
                .thenReturn(com.city.authservice.dto.User.builder().build());

        // When
        AuthResponse response = authService.register(registerRequest);

        // Then
        assertNotNull(response);
        assertEquals(Role.CITIZEN, response.getRole());
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    void register_ShouldHandleEmployeeRole_WhenRoleIsEmployee() {
        // Given
        registerRequest.setRole(Role.EMPLOYEE);
        User employeeUser = User.builder()
                .id(1L)
                .username("employee")
                .email("emp@example.com")
                .password("encodedPassword")
                .role(Role.EMPLOYEE)
                .build();

        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(employeeUser);
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(userDetails);
        when(jwtUtil.generateToken(anyString(), anyString(), any(Long.class))).thenReturn("jwt-token");
        when(userClient.createUser(any(com.city.authservice.dto.User.class)))
                .thenReturn(com.city.authservice.dto.User.builder().build());

        // When
        AuthResponse response = authService.register(registerRequest);

        // Then
        assertNotNull(response);
        assertEquals(Role.EMPLOYEE, response.getRole());
        verify(userClient, times(1)).createUser(argThat(userDto -> 
                "EMPLOYEE".equals(userDto.getRole())
        ));
    }

    @Test
    void register_ShouldHandleAdminRole_WhenRoleIsAdmin() {
        // Given
        registerRequest.setRole(Role.ADMIN);
        User adminUser = User.builder()
                .id(1L)
                .username("admin")
                .email("admin@example.com")
                .password("encodedPassword")
                .role(Role.ADMIN)
                .build();

        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(adminUser);
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(userDetails);
        when(jwtUtil.generateToken(anyString(), anyString(), any(Long.class))).thenReturn("jwt-token");
        when(userClient.createUser(any(com.city.authservice.dto.User.class)))
                .thenReturn(com.city.authservice.dto.User.builder().build());

        // When
        AuthResponse response = authService.register(registerRequest);

        // Then
        assertNotNull(response);
        assertEquals(Role.ADMIN, response.getRole());
        verify(userClient, times(1)).createUser(argThat(userDto -> 
                "ADMIN".equals(userDto.getRole())
        ));
    }

    @Test
    void login_ShouldReturnAuthResponse_WhenValidCredentials() {
        // Given
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(null);
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(userDetails);
        when(userRepository.findByUsername(anyString())).thenReturn(Optional.of(user));
        when(jwtUtil.generateToken(anyString(), anyString(), any(Long.class))).thenReturn("jwt-token");

        // When
        AuthResponse response = authService.login(loginRequest);

        // Then
        assertNotNull(response);
        assertEquals("jwt-token", response.getToken());
        assertEquals(Role.CITIZEN, response.getRole());
        assertEquals(1L, response.getUserId());

        verify(authenticationManager, times(1)).authenticate(any(UsernamePasswordAuthenticationToken.class));
        verify(userRepository, times(1)).findByUsername(anyString());
    }

    @Test
    void login_ShouldHandleEmployeeLogin_WhenUserIsEmployee() {
        // Given
        User employeeUser = User.builder()
                .id(2L)
                .username("employee")
                .email("emp@example.com")
                .password("encodedPassword")
                .role(Role.EMPLOYEE)
                .build();

        com.city.authservice.dto.User employeeDto = com.city.authservice.dto.User.builder()
                .id(10L)
                .name("Employee Name")
                .email("emp@example.com")
                .role("EMPLOYEE")
                .authUserId(2L)
                .build();

        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(null);
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(userDetails);
        when(userRepository.findByUsername(anyString())).thenReturn(Optional.of(employeeUser));
        when(jwtUtil.generateToken(anyString(), anyString(), any(Long.class))).thenReturn("jwt-token");
        when(userClient.getUserByAuthUserId(2L)).thenReturn(employeeDto);

        // When
        AuthResponse response = authService.login(loginRequest);

        // Then
        assertNotNull(response);
        assertEquals("jwt-token", response.getToken());
        assertEquals(Role.EMPLOYEE, response.getRole());
        assertEquals(10L, response.getUserId()); // Should return the employee service user ID

        verify(userClient, times(1)).getUserByAuthUserId(2L);
    }

    @Test
    void login_ShouldHandleEmployeeWithoutUserService_WhenUserClientReturnsNull() {
        // Given
        User employeeUser = User.builder()
                .id(2L)
                .username("employee")
                .email("emp@example.com")
                .password("encodedPassword")
                .role(Role.EMPLOYEE)
                .build();

        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(null);
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(userDetails);
        when(userRepository.findByUsername(anyString())).thenReturn(Optional.of(employeeUser));
        when(jwtUtil.generateToken(anyString(), anyString(), any(Long.class))).thenReturn("jwt-token");
        when(userClient.getUserByAuthUserId(2L)).thenReturn(null);

        // When
        AuthResponse response = authService.login(loginRequest);

        // Then
        assertNotNull(response);
        assertEquals("jwt-token", response.getToken());
        assertEquals(Role.EMPLOYEE, response.getRole());
        assertEquals(2L, response.getUserId()); // Should fallback to auth user ID

        verify(userClient, times(1)).getUserByAuthUserId(2L);
    }

    @Test
    void login_ShouldThrowException_WhenUserNotFound() {
        // Given
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(null);
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(userDetails);
        when(userRepository.findByUsername(anyString())).thenReturn(Optional.empty());

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            authService.login(loginRequest);
        });

        assertEquals("User not found", exception.getMessage());
        verify(userRepository, times(1)).findByUsername(anyString());
    }

    @Test
    void login_ShouldThrowException_WhenAuthenticationFails() {
        // Given
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenThrow(new BadCredentialsException("Bad credentials"));

        // When & Then
        BadCredentialsException exception = assertThrows(BadCredentialsException.class, () -> {
            authService.login(loginRequest);
        });

        assertEquals("Bad credentials", exception.getMessage());
        verify(authenticationManager, times(1)).authenticate(any(UsernamePasswordAuthenticationToken.class));
    }

    @Test
    void register_ShouldHandleUserClientFailure_WhenUserClientThrowsException() {
        // Given
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(user);
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(userDetails);
        when(jwtUtil.generateToken(anyString(), anyString(), any(Long.class))).thenReturn("jwt-token");
        when(userClient.createUser(any(com.city.authservice.dto.User.class)))
                .thenThrow(new RuntimeException("User service unavailable"));

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            authService.register(registerRequest);
        });

        assertEquals("User service unavailable", exception.getMessage());
        verify(userRepository, times(1)).save(any(User.class));
        verify(userClient, times(1)).createUser(any(com.city.authservice.dto.User.class));
    }

    @Test
    void register_ShouldHandleNullPhone_WhenPhoneIsNull() {
        // Given
        registerRequest.setPhone(null);
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(user);
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(userDetails);
        when(jwtUtil.generateToken(anyString(), anyString(), any(Long.class))).thenReturn("jwt-token");
        when(userClient.createUser(any(com.city.authservice.dto.User.class)))
                .thenReturn(com.city.authservice.dto.User.builder().build());

        // When
        AuthResponse response = authService.register(registerRequest);

        // Then
        assertNotNull(response);
        verify(userClient, times(1)).createUser(argThat(userDto -> 
                userDto.getPhone() == null
        ));
    }

    @Test
    void login_ShouldHandleAdminLogin_WhenUserIsAdmin() {
        // Given
        User adminUser = User.builder()
                .id(3L)
                .username("admin")
                .email("admin@example.com")
                .password("encodedPassword")
                .role(Role.ADMIN)
                .build();

        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(null);
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(userDetails);
        when(userRepository.findByUsername(anyString())).thenReturn(Optional.of(adminUser));
        when(jwtUtil.generateToken(anyString(), anyString(), any(Long.class))).thenReturn("jwt-token");

        // When
        AuthResponse response = authService.login(loginRequest);

        // Then
        assertNotNull(response);
        assertEquals("jwt-token", response.getToken());
        assertEquals(Role.ADMIN, response.getRole());
        assertEquals(3L, response.getUserId());

        // Admin should not call user client
        verify(userClient, never()).getUserByAuthUserId(any(Long.class));
    }
}