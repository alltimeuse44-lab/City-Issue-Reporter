package com.city.authservice.controller;

import com.city.authservice.dto.AuthResponse;
import com.city.authservice.dto.LoginRequest;
import com.city.authservice.dto.RegisterRequest;
import com.city.authservice.entity.Role;
import com.city.authservice.service.AuthService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class AuthControllerTest {

    @Mock
    private AuthService authService;

    @InjectMocks
    private AuthController authController;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(authController).build();
        objectMapper = new ObjectMapper();
    }

    @Test
    void register_ShouldReturnAuthResponse_WhenValidRequest() throws Exception {
        // Given
        RegisterRequest request = RegisterRequest.builder()
                .username("testuser")
                .email("test@example.com")
                .password("password123")
                .phone("1234567890")
                .role(Role.CITIZEN)
                .build();

        AuthResponse response = AuthResponse.builder()
                .token("jwt-token")
                .role(Role.CITIZEN)
                .userId(1L)
                .build();

        when(authService.register(any(RegisterRequest.class))).thenReturn(response);

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("jwt-token"))
                .andExpect(jsonPath("$.role").value("CITIZEN"))
                .andExpect(jsonPath("$.userId").value(1));

        verify(authService, times(1)).register(any(RegisterRequest.class));
    }

    @Test
    void register_ShouldHandleNullPhone_WhenPhoneIsNull() throws Exception {
        // Given
        RegisterRequest request = RegisterRequest.builder()
                .username("testuser")
                .email("test@example.com")
                .password("password123")
                .phone(null)
                .role(Role.CITIZEN)
                .build();

        AuthResponse response = AuthResponse.builder()
                .token("jwt-token")
                .role(Role.CITIZEN)
                .userId(1L)
                .build();

        when(authService.register(any(RegisterRequest.class))).thenReturn(response);

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());

        verify(authService, times(1)).register(any(RegisterRequest.class));
    }

    @Test
    void register_ShouldHandleAdminRole_WhenRoleIsAdmin() throws Exception {
        // Given
        RegisterRequest request = RegisterRequest.builder()
                .username("admin")
                .email("admin@example.com")
                .password("password123")
                .phone("1234567890")
                .role(Role.ADMIN)
                .build();

        AuthResponse response = AuthResponse.builder()
                .token("jwt-token")
                .role(Role.ADMIN)
                .userId(1L)
                .build();

        when(authService.register(any(RegisterRequest.class))).thenReturn(response);

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.role").value("ADMIN"));

        verify(authService, times(1)).register(any(RegisterRequest.class));
    }

    @Test
    void register_ShouldHandleEmployeeRole_WhenRoleIsEmployee() throws Exception {
        // Given
        RegisterRequest request = RegisterRequest.builder()
                .username("employee")
                .email("employee@example.com")
                .password("password123")
                .phone("1234567890")
                .role(Role.EMPLOYEE)
                .build();

        AuthResponse response = AuthResponse.builder()
                .token("jwt-token")
                .role(Role.EMPLOYEE)
                .userId(1L)
                .build();

        when(authService.register(any(RegisterRequest.class))).thenReturn(response);

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.role").value("EMPLOYEE"));

        verify(authService, times(1)).register(any(RegisterRequest.class));
    }

    @Test
    void login_ShouldReturnAuthResponse_WhenValidCredentials() throws Exception {
        // Given
        LoginRequest request = LoginRequest.builder()
                .username("testuser")
                .password("password123")
                .build();

        AuthResponse response = AuthResponse.builder()
                .token("jwt-token")
                .role(Role.CITIZEN)
                .userId(1L)
                .build();

        when(authService.login(any(LoginRequest.class))).thenReturn(response);

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("jwt-token"))
                .andExpect(jsonPath("$.role").value("CITIZEN"))
                .andExpect(jsonPath("$.userId").value(1));

        verify(authService, times(1)).login(any(LoginRequest.class));
    }

    @Test
    void login_ShouldHandleAdminLogin_WhenAdminCredentials() throws Exception {
        // Given
        LoginRequest request = LoginRequest.builder()
                .username("admin")
                .password("adminpass")
                .build();

        AuthResponse response = AuthResponse.builder()
                .token("admin-jwt-token")
                .role(Role.ADMIN)
                .userId(2L)
                .build();

        when(authService.login(any(LoginRequest.class))).thenReturn(response);

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("admin-jwt-token"))
                .andExpect(jsonPath("$.role").value("ADMIN"))
                .andExpect(jsonPath("$.userId").value(2));

        verify(authService, times(1)).login(any(LoginRequest.class));
    }

    @Test
    void login_ShouldHandleEmployeeLogin_WhenEmployeeCredentials() throws Exception {
        // Given
        LoginRequest request = LoginRequest.builder()
                .username("employee")
                .password("emppass")
                .build();

        AuthResponse response = AuthResponse.builder()
                .token("emp-jwt-token")
                .role(Role.EMPLOYEE)
                .userId(3L)
                .build();

        when(authService.login(any(LoginRequest.class))).thenReturn(response);

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("emp-jwt-token"))
                .andExpect(jsonPath("$.role").value("EMPLOYEE"))
                .andExpect(jsonPath("$.userId").value(3));

        verify(authService, times(1)).login(any(LoginRequest.class));
    }

    @Test
    void register_ShouldHandleServiceException_WhenServiceThrowsException() throws Exception {
        // Given
        RegisterRequest request = RegisterRequest.builder()
                .username("testuser")
                .email("test@example.com")
                .password("password123")
                .phone("1234567890")
                .role(Role.CITIZEN)
                .build();

        when(authService.register(any(RegisterRequest.class)))
                .thenThrow(new RuntimeException("Registration failed"));

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().is5xxServerError());

        verify(authService, times(1)).register(any(RegisterRequest.class));
    }

    @Test
    void login_ShouldHandleServiceException_WhenServiceThrowsException() throws Exception {
        // Given
        LoginRequest request = LoginRequest.builder()
                .username("testuser")
                .password("wrongpassword")
                .build();

        when(authService.login(any(LoginRequest.class)))
                .thenThrow(new RuntimeException("Authentication failed"));

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().is5xxServerError());

        verify(authService, times(1)).login(any(LoginRequest.class));
    }

    @Test
    void register_ShouldHandleEmptyRequest_WhenRequestIsEmpty() throws Exception {
        // Given
        RegisterRequest request = RegisterRequest.builder().build();

        AuthResponse response = AuthResponse.builder()
                .token("jwt-token")
                .role(Role.CITIZEN)
                .userId(1L)
                .build();

        when(authService.register(any(RegisterRequest.class))).thenReturn(response);

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());

        verify(authService, times(1)).register(any(RegisterRequest.class));
    }

    @Test
    void login_ShouldHandleEmptyRequest_WhenRequestIsEmpty() throws Exception {
        // Given
        LoginRequest request = LoginRequest.builder().build();

        AuthResponse response = AuthResponse.builder()
                .token("jwt-token")
                .role(Role.CITIZEN)
                .userId(1L)
                .build();

        when(authService.login(any(LoginRequest.class))).thenReturn(response);

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());

        verify(authService, times(1)).login(any(LoginRequest.class));
    }
}