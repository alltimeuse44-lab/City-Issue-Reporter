package com.city.authservice.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JwtUtilTest {

    @Mock
    private JwtConfig jwtConfig;

    @InjectMocks
    private JwtUtil jwtUtil;

    private final String secret = "testSecret";
    private final long expiration = 86400000;

    @BeforeEach
    void setUp() {
        when(jwtConfig.getSecret()).thenReturn(secret);
        when(jwtConfig.getExpiration()).thenReturn(expiration);
    }

    @Test
    void generateToken_Success() {
        String token = jwtUtil.generateToken("testuser", "CITIZEN", 1L);
        assertNotNull(token);
        
        Claims claims = Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
        assertEquals("testuser", claims.getSubject());
        assertEquals(1L, claims.get("userId", Long.class));
        assertEquals("CITIZEN", claims.get("role", String.class));
    }

    @Test
    void extractUsername_Success() {
        String token = jwtUtil.generateToken("testuser", "CITIZEN", 1L);
        assertEquals("testuser", jwtUtil.extractUsername(token));
    }

    @Test
    void validateToken_ValidToken() {
        String token = jwtUtil.generateToken("testuser", "CITIZEN", 1L);
        assertTrue(jwtUtil.validateToken(token, "testuser"));
    }

    @Test
    void validateToken_InvalidUsername() {
        String token = jwtUtil.generateToken("testuser", "CITIZEN", 1L);
        assertFalse(jwtUtil.validateToken(token, "wronguser"));
    }

    @Test
    void validateToken_ExpiredToken() {
        String expiredToken = Jwts.builder()
                .setSubject("testuser")
                .setExpiration(new Date(System.currentTimeMillis() - 1000))
                .signWith(SignatureAlgorithm.HS512, secret)
                .compact();
        assertFalse(jwtUtil.validateToken(expiredToken, "testuser"));
    }
}