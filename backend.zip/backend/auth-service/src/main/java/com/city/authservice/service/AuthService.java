package com.city.authservice.service;

import com.city.authservice.dto.*;
import com.city.authservice.entity.Role;
import com.city.authservice.entity.User;
import com.city.authservice.feignClient.UserClient;
import com.city.authservice.repository.UserRepository;
import com.city.authservice.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    private final CustomUserDetailsService userDetailsService;
    private final UserClient userClient;

    public AuthResponse register(RegisterRequest request) {
        // ✅ Ensure role is not null (default CITIZEN)
        Role role = (request.getRole() != null) ? request.getRole() : Role.CITIZEN;

        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(role)
                .build();

        User savedUser = userRepository.save(user);

        // Call UserService to create mapping record
        String userServiceRole = role == Role.EMPLOYEE ? "EMPLOYEE" : role.name();
        userClient.createUser(com.city.authservice.dto.User.builder()
                .name(request.getUsername())
                .email(request.getEmail())
                .phone(request.getPhone())
                .role(userServiceRole)
                .authUserId(savedUser.getId())
                .build());

        UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());
        String token = jwtUtil.generateToken(
                user.getUsername(),
                userDetails.getAuthorities().iterator().next().getAuthority(),
                user.getId()
        );

        return AuthResponse.builder()
                .token(token)
                .role(role)
                .userId(savedUser.getId()) // Return id so frontend can map
                .build();
    }

    public AuthResponse login(LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword()
                )
        );

        UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());

        // Fetch actual User entity
        User authUser = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        String token = jwtUtil.generateToken(
                authUser.getUsername(),
                userDetails.getAuthorities().iterator().next().getAuthority(),
                authUser.getId()
        );

        Long userId = null;

        if (authUser.getRole() == Role.EMPLOYEE) {
            com.city.authservice.dto.User userDto = userClient.getUserByAuthUserId(authUser.getId());
            if (userDto != null) {
                userId = userDto.getId();
            }
        }

        return AuthResponse.builder()
                .token(token)
                .role(authUser.getRole())
                .userId(userId != null ? userId : authUser.getId())
                .build();
    }
}



//package com.city.authservice.service;
//
//import com.city.authservice.dto.*;
//import com.city.authservice.entity.Role;
//import com.city.authservice.entity.User;
//import com.city.authservice.feignClient.UserClient;
//import com.city.authservice.repository.UserRepository;
//import com.city.authservice.security.JwtUtil;
//import lombok.RequiredArgsConstructor;
//import org.springframework.security.authentication.*;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//
//@Service
//@RequiredArgsConstructor
//public class AuthService {
//
//    private final UserRepository userRepository;
//    private final PasswordEncoder passwordEncoder;
//    private final AuthenticationManager authenticationManager;
//    private final JwtUtil jwtUtil;
//    private final CustomUserDetailsService userDetailsService;
//    private final UserClient userClient;
//
//    public AuthResponse register(RegisterRequest request) {
//        // ✅ Ensure role is not null (default CITIZEN)
//        Role role = (request.getRole() != null) ? request.getRole() : Role.CITIZEN;
//
//        User user = User.builder()
//                .username(request.getUsername())
//                .email(request.getEmail())
//                .password(passwordEncoder.encode(request.getPassword()))
//                .role(role)
//                .build();
//
//        User savedUser = userRepository.save(user);
//
//        // Call UserService to create mapping record
//        userClient.createUser(com.city.authservice.dto.User.builder()
//                .name(request.getUsername())
//                .email(request.getEmail())
//                .phone(request.getPhone())
//                .role(role.name())
//                .authUserId(savedUser.getId())
//                .build());
//
//        UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());
//        String token = jwtUtil.generateToken(
//                user.getUsername(),
//                userDetails.getAuthorities().iterator().next().getAuthority(),
//                user.getId()
//        );
//
//        return AuthResponse.builder()
//                .token(token)
//                .role(role)
//                .userId(savedUser.getId()) // Return id so frontend can map
//                .build();
//    }
//
//    public AuthResponse login(LoginRequest request) {
//        authenticationManager.authenticate(
//                new UsernamePasswordAuthenticationToken(
//                        request.getUsername(),
//                        request.getPassword()
//                )
//        );
//
//        UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());
//
//        // Fetch actual User entity
//        User authUser = userRepository.findByUsername(request.getUsername())
//                .orElseThrow(() -> new RuntimeException("User not found"));
//
//        String token = jwtUtil.generateToken(
//                authUser.getUsername(),
//                userDetails.getAuthorities().iterator().next().getAuthority(),
//                authUser.getId()
//        );
//
//        Long userId = null;
//
//        if (authUser.getRole() == Role.EMPLOYEE) {
//            com.city.authservice.dto.User userDto = userClient.getUserByAuthUserId(authUser.getId());
//            if (userDto != null) {
//                userId = userDto.getId();
//            }
//        }
//
//        return AuthResponse.builder()
//                .token(token)
//                .role(authUser.getRole())
//                .userId(userId != null ? userId : authUser.getId())
//                .build();
//    }
//}
