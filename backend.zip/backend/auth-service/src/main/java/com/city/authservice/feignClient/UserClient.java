package com.city.authservice.feignClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.city.authservice.dto.User;

@FeignClient(name = "user-service", url = "http://localhost:8080")
public interface UserClient {
    @PostMapping("/api/users")
    User createUser(@RequestBody User user);

    @GetMapping("/api/users/auth/{authUserId}")
    User getUserByAuthUserId(@PathVariable Long authUserId);
}
