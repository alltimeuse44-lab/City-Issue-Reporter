package com.city.authservice.dto;


import com.city.authservice.entity.Role;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthResponse {
    private String token;
    private Role role;
    private Long userId; // Renamed from doctorId
}
