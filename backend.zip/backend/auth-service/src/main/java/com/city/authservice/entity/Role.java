package com.city.authservice.entity;

public enum Role {
	ADMIN,
    EMPLOYEE,
    CITIZEN
}
