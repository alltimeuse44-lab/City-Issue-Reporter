package com.city.authservice.dto;

import com.city.authservice.entity.Role;

import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequest {
    private String username;
    private String email;
    private String password;
    private Role role;
    private String phone;  // <-- This must exist!
}
