package com.city.authservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.city.authservice.entity.User;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
}
